<?php

namespace App\Http\Controllers;

use App\BoughtVideos;
use App\Payouts;
use App\User;
use App\Videos;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class VideosController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $videos = Videos::where('username', auth()->user()->username)->orderby('video_id', 'DESC')->get();
        $downloads = BoughtVideos::where('bought_video_artist', auth()->user()->username)->count();
        $payouts = Payouts::where('username', auth()->user()->username)->sum('amount');
        return view('/pages/studio')->with(['videos' => $videos, 'downloads' => $downloads, 'payouts' => $payouts]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('/pages/video-create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'video' => 'regex:/^https:\/\/youtu.be\/[A-z0-9]+/',
            'vArt' => 'image|max:1999',
        ]);

        /* Handle file upload */
        if ($request->hasFile('vArt')) {
            $vArt = $request->file('vArt')->store('public/vArt');
            $vArt = substr($vArt, 7);
        } else {
            $vArt = "";
        }

        /* Create new video song */
        $video = new Videos;
        /* Change url to enable embedding */
        $video->video = substr_replace($request->input('video'), 'https://www.youtube.com/embed', 0, 16);
        $video->video_name = $request->input('video-name');
        $video->username = auth()->user()->username;
        if ($request->ft) {
            $ftCheck = User::where('username', $request->ft)->count();
            if ($ftCheck > 0) {
                $video->ft = $request->input('ft') ? $request->input('ft') : "";
            } else {
                return redirect('/videos/create')->with('error', 'Featuring artist must have an account.');
            }
        }
        $video->video_album = "";
        $video->video_genre = $request->input('video-genre');
        $video->video_thumbnail = $vArt;
        $video->video_description = $request->input('description');
        $video->save();

        $userAcc = User::find(auth()->user()->user_id);
        if ($userAcc->acc_type == 'normal') {
            $userAcc->acc_type = 'musician';
            $userAcc->save();
        }

        return redirect('/videos/create')->with('success', 'Video Uploaded');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Videos  $videos
     * @return \Illuminate\Http\Response
     */
    public function show(Videos $videos)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Videos  $videos
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $video = Videos::where('video_id', $id)->first();
        return view('pages/video-edit')->with('video', $video);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Videos  $videos
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'string|nullable|max:20',
            'phone' => 'string|nullable|startsWith:07|min:10|max:10',
            'email' => 'string|nullable|email|max:255|unique:users',
            'password' => 'string|nullable|min:8|confirmed',
            'profile-pic' => 'image|nullable|max:9999',
            'bio' => 'string|nullable|max:50',
            'loc' => 'string|nullable',
            'withdrawal' => 'string|nullable',
        ]);

        /* Update video */
        $video = Videos::find($id);
        if ($request->filled('video-name')) {
            $video->video_name = $request->input('video-name');
        } else {
            $video->video = $video->video;
        }
        if ($request->filled('ft')) {
            $ftCheck = User::where('username', $request->ft)->count();
            if ($ftCheck > 0) {
                $video->ft = $request->input('ft') ? $request->input('ft') : "";
            } else {
                return redirect('/videos/' . $id . '/edit')->with('error', 'Featuring artist must have an account.');
            }
        } else {
            $video->ft = $video->ft;
        }

        if ($request->filled('video-genre')) {
            $video->video_genre = $request->input('video-genre');
        } else {
            $video->video_genre = $video->video_genre;
        }

        /* Handle file upload */
        if ($request->hasFile('vArt')) {
            Storage::delete('public/' . $video->video_thumbnail);
            $vArt = $request->file('vArt')->store('public/vArt');
            $vArt = substr($vArt, 7);
            $video->video_thumbnail = $vArt;
        } else {
            $video->video_thumbnail = $video->video_thumbnail;
        }

        if ($request->filled('description')) {
            $video->video_description = $request->input('description');
        } else {
            $video->video_description = $video->video_description;
        }

        $video->save();
        return redirect('/videos/' . $id . '/edit')->with('success', 'Video Updated');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Videos  $videos
     * @return \Illuminate\Http\Response
     */
    public function destroy(Videos $videos)
    {
        //
    }
}
