<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kopokopo extends Model
{
    public $table = 'Kopokopo';
}
