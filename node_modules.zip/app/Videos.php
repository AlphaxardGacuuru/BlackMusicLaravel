<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Videos extends Model
{
    protected $primaryKey = "video_id";

    public function bought_videos()
    {
        return $this->hasMany('App\BoughtVideos', 'video_id', 'video_id');
    }

    public function cart_videos()
    {
        return $this->hasMany('App\CartVideos', 'video_id', 'video_id');
    }

    public function video_likes()
    {
        return $this->hasMany('App\VideoLikes', 'video_id', 'video_id');
    }

    public function video_notifications()
    {
        return $this->hasMany('App\VideoNotifications', 'video_id', 'video_id');
    }
}
