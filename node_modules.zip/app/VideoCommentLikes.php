<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VideoCommentLikes extends Model
{
    //
}
