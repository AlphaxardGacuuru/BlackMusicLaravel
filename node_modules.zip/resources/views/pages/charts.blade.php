@php
    use App\BoughtVideos;
    use App\VideoLikes;
    use App\Videos;
    use App\Follow;
    use App\CartVideos;
    use App\User;
@endphp
@extends('layouts/app')
@section('content')
@include('inc/topnav')
<br>
<br>
<br class="hidden">
@guest
    @php
        class Fruit {
        /* Guest properties */
        public $name = 'Guest';
        public $username = '@guest';
        public $email;
        public $phone;
        public $gender;
        public $acc_type = 'normal';
        public $acc_type_2;
        public $pp = 'profile-pics/male_avatar.png';
        public $pb;
        public $bio;
        public $dob;
        public $decos = [1];
        public $location;
        public $withdrawal;
        }

        $user = new Fruit();
    @endphp
@else
    @php
        $user = Auth::user();
    @endphp
@endguest
@php
    /* Function for adding into an array */
    function array_push_assoc($array, $key, $value){
    $array[$key] = $value;
    return $array;
    }
    $newlyClass = $trendClass = $topDownClass = $topLovedClass = $orderBy = $boughtVideo = $minDate = $artistsWHERE =
    "";
    if ($chart == 'newlyReleased') {
    $videoChart = Videos::get();
    $minDate = 30;
    $orderBy = 'video_id';
    $ANDvSong_id = '';
    $newlyClass = "class='active-scrollmenu'";
    } elseif ($chart == 'trending') {
    $videoChart = BoughtVideos::get();
    $minDate = 7;
    $orderBy = 'video_id';
    $ANDvSong_id = 'AND video_id =';
    $trendClass = "class='active-scrollmenu'";
    } elseif ($chart == 'topDownloaded') {
    $videoChart = BoughtVideos::get();
    $minDate = 1000;
    $orderBy = 'vsong_downloads';
    $ANDvSong_id = 'AND video_id =';
    $topDownClass = "class='active-scrollmenu'";
    } elseif ($chart == 'topLoved') {
    $videoChart = VideoLikes::get();
    $minDate = 100;
    $orderBy = 'vsong_loves';
    $ANDvSong_id = 'AND video_id =';
    $topLovedClass = "class='active-scrollmenu'";
    }

    $AllClass = $AfroClass = $BengaClass = $BluesClass = $BoombaClass = $CountryClass = $CulturalClass = $EDMClass =
    $GengeClass = $GospelClass = $HiphopClass = $JazzClass = $MoKClass = $PopClass = $RandBClass = $RockClass =
    $SesubeClass = $TaarabClass = "";
    if ($vGenre == 'All') {
    $ANDvGenre = "";
    $AllClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Afro') {
    $ANDvGenre = 'AND vgenre = "Afro"';
    $AfroClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Benga') {
    $ANDvGenre = 'AND vgenre = "Benga"';
    $BengaClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Blues') {
    $ANDvGenre = 'AND vgenre = "Blues"';
    $BluesClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Boomba') {
    $ANDvGenre = 'AND vgenre = "Boomba"';
    $BoombaClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Country') {
    $ANDvGenre = 'AND vgenre = "Country"';
    $CountryClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Cultural') {
    $ANDvGenre = 'AND vgenre = "Cultural"';
    $CulturalClass = "class='active-scrollmenu'";
    }elseif ($vGenre == 'EDM') {
    $ANDvGenre = 'AND vgenre = "EDM"';
    $EDMClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Genge') {
    $ANDvGenre = 'AND vgenre = "Genge"';
    $GengeClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Gospel') {
    $ANDvGenre = 'AND video_genre = "Gospel"';
    $GospelClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Hiphop') {
    $ANDvGenre = 'AND video_genre = "Hiphop"';
    $HiphopClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Jazz') {
    $ANDvGenre = 'AND vgenre = "Jazz"';
    $JazzClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'MoK') {
    $ANDvGenre = 'AND vgenre = "Music of Kenya"';
    $MoKClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Pop') {
    $ANDvGenre = 'AND vgenre = "Pop"';
    $PopClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'RandB') {
    $ANDvGenre = 'AND vgenre = "R&B"';
    $RandBClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Rock') {
    $ANDvGenre = 'AND vgenre = "Rock"';
    $RockClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Sesube') {
    $ANDvGenre = 'AND vgenre = "Sesube"';
    $SesubeClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Taarab') {
    $ANDvGenre = 'AND vgenre = "Taarab"';
    $TaarabClass = "class='active-scrollmenu'";
    }
@endphp
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
        <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
        <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
        @php
            $carousel = Videos::orderby('video_id', 'DESC')->limit(3)->get();
            $i = 1;
        @endphp
        @foreach($carousel as $item)
            <div class="carousel-item @if($i == 1){{ 'active' }}@endif" style="overflow: hidden;">
                <img class="d-block w-100" src="/storage/{{ $item->video_thumbnail }}" alt="Thumbnail">
                <div class="carousel-caption d-none d-md-block">
                    <h5>{{ $item->video_name }}</h5>
                    <p>{{ $item->username }}</p>
                </div>
            </div>
            @php
                $i++;
            @endphp
        @endforeach
    </div>
    <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
    </a>
</div>

<!-- Scroll menu -->
<div id="chartsMenu" class="hidden-scroll" style="margin: 10px 0 0 0;">
    <span><a href="/charts/newlyReleased/All">
            <h5 <?php echo $newlyClass; ?>>Newly Released</h5>
        </a></span>
    <span><a href="/charts/trending/All">
            <h5 <?php echo $trendClass; ?>>Trending</h5>
        </a></span>
    <span><a href="/charts/topDownloaded/All">
            <h5 <?php echo $topDownClass; ?>>Top Downloaded</h5>
        </a></span>
    <span><a href="/charts/topLoved/All">
            <h5 <?php echo $topLovedClass; ?>>Top Loved</h5>
        </a></span>
</div>

<div id="chartsMenu" class="hidden-scroll" style="margin: 0 0 0 0;">
    <span>
        <a href="/charts/<?php echo $chart; ?>/All">
            <h6 <?php echo $AllClass; ?>>All</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Afro">
            <h6 <?php echo $AfroClass; ?>>Afro</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Benga">
            <h6 <?php echo $BengaClass; ?>>Benga</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Blues">
            <h6 <?php echo $BluesClass; ?>>Blues</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Boomba">
            <h6 <?php echo $BoombaClass; ?>>Boomba</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Country">
            <h6 <?php echo $CountryClass; ?>>Country</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Cultural">
            <h6 <?php echo $CulturalClass; ?>>Cultural</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/EDM">
            <h6 <?php echo $EDMClass; ?>>EDM</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Genge">
            <h6 <?php echo $GengeClass; ?>>Genge</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Gospel">
            <h6 <?php echo $GospelClass; ?>>Gospel</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Hiphop">
            <h6 <?php echo $HiphopClass; ?>>Hiphop</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Jazz">
            <h6 <?php echo $JazzClass; ?>>Jazz</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/MoK">
            <h6 <?php echo $MoKClass; ?>>Music of Kenya</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Pop">
            <h6 <?php echo $PopClass; ?>>Pop</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/RandB">
            <h6 <?php echo $RandBClass; ?>>R&B</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Rock">
            <h6 <?php echo $RockClass; ?>>Rock</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Sesube">
            <h6 <?php echo $SesubeClass; ?>>Sesube</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Taarab">
            <h6 <?php echo $TaarabClass; ?>>Taarab</h6>
        </a>
    </span>
</div>
<!-- End of scroll menu -->

<!-- Chart Area -->
<div class="row hidden">
    <div class="col-sm-12">

        <!-- ****** Artists Area Start ****** -->
        <h5>Artists</h5>
        <div class="hidden-scroll">
            @php
                /*Get relevant songs*/
                /*Add to trend_week*/
                $trendWeek = strtotime("next Friday");
                $trendWeek = getdate($trendWeek);
                $dVar = $trendWeek[0];
                $trendingVids = array();
            @endphp
            @foreach($videoChart as $videoChart)
                @php
                    if ($chart == 'trending' || $chart == 'topDownloaded' || $chart == 'topLoved') {
                    $tDate = $dVar - strtotime($videoChart->created_at);
                    $boughtVideo = $videoChart->video_id;
                    } else {
                    $tDate = 0;
                    $boughtVideo = $videoChart->video_id;
                    }
                    $tDate = $tDate/86400;
                @endphp
                @if($tDate < $minDate)
                    @if(array_key_exists($boughtVideo, $trendingVids))
                        @php
                            $trendingVids[$boughtVideo] += 1;
                        @endphp
                    @else
                        @php
                            $trendingVids = array_push_assoc($trendingVids, $boughtVideo, 1);
                        @endphp
                    @endif
                @endif
            @endforeach
            @php
                arsort($trendingVids);
                /* echo print_r($trendingVids) . '<br>' ;
                echo count($trendingVids) . "<br>"; */

                /*Create relevant array for artist*/
                $trendingArtists = array();
            @endphp
            @foreach($trendingVids as $boughtVideo => $downloads)
                @php
                    $fetchArtist = Videos::where('video_id', $boughtVideo)->first();
                @endphp
                @if(array_key_exists($fetchArtist->username, $trendingArtists))
                    @php
                        $trendingArtists[$fetchArtist->username] += $downloads;
                    @endphp
                @else
                    @php
                        $trendingArtists = array_push_assoc($trendingArtists, $fetchArtist->username,
                        $downloads);
                    @endphp
                @endif
            @endforeach
            @php
                arsort($trendingArtists);
                /* echo print_r($trendingArtists) . '<br>';
                echo count($trendingArtists) . "<br>"; */
            @endphp

            {{-- Get winner --}}
            @if($chart == 'trending')
                @php
                    $referralList = array();
                @endphp
                @foreach($trendingArtists as $trendingArtist => $userDownloads)
                    @php
                        $referrals = Referrals::where('username', $trendingArtist)->get();
                        $referralCount = $referrals->count();
                    @endphp
                    @if($referralCount >= 2)
                        @for($i=0; $i < $referralCount; $i++)
                            @php
                                $rSongFetch = Videos::where('username', $referrals->referrer);
                            @endphp
                            @if($rSongFetch)
                                @if(array_key_exists($trendingArtist, $trendingArtists))
                                    @php
                                        $referralList[$trendingArtist] +=1;
                                    @endphp
                                @else
                                    @php
                                        $referralList = array_push_assoc($referralList, $trendingArtist, 1);
                                    @endphp
                                @endif
                            @endif
                        @endfor
                    @endif
                @endforeach
                @php
                    arsort($referralList);
                    /* echo print_r($referralList) . '<br>' ; echo count($referralList)
                    . "<br>" ; echo key($referralList) . "<br>" ; */
                    $winner = key($referralList);
                @endphp
            @endif

            {{-- Echo Artists according to most songs sold in one week --}}
            @foreach($trendingArtists as $trendingArtist => $userDownloads)
                @if($chart == 'trending')
                    @if($trendingArtist == $winner)
                        @php
                            $position = "<h6 style='background-color: green;'>
                                <small style='color: white;'>Top</small>
                            </h6>
                            ";
                        @endphp
                    @elseif(array_key_exists($trendingArtist, $referralList))
                        @php
                            $position = "<h6 style='background-color: green;'>
                                <small style='color: white;'>$userDownloads Downloads</small>
                            </h6>";
                        @endphp
                    @else
                        @php
                            $position = "<h6 style='background-color: orange;'>
                                <small style='color: white;'>$userDownloads Downloads</small>
                            </h6>";
                        @endphp
                    @endif
                @else
                    @php
                        $position = "";
                    @endphp
                @endif
                @php
                    $musician = User::where('username', $trendingArtist)->first();
                    $followQuery = Follow::where('followed', $trendingArtist)->where('username',
                    $user->username)->count();
                    $boughtVideosQuery = BoughtVideos::where('username',
                    $user->username)->where('bought_video_artist', $trendingArtist)->count();
                    if ($followQuery == 0) {
                    if ($boughtVideosQuery > 0 || $user->username == '@blackmusic') {
                    $fBtn =
                    Form::submit('follow', ['class' => 'mysonar-btn float-right']);
                    } else {
                    $fBtn = Form::button('follow', ['class' => 'mysonar-btn', 'onclick' =>
                    'checkerSnackbar()']);
                    }
                    } else {
                    $fBtn = Form::button("
                    Followed
                    <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                        xmlns='http://www.w3.org/2000/svg'>
                        <path fill-rule='evenodd'
                            d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                    </svg>",
                    ['type' => 'submit', 'class' => 'btn btn-light']);
                    }
                @endphp
                <span class="pt-0 pl-0 pr-0 pb-2" style='border-radius: 10px'>
                    <center>
                        <div class="card avatar-thumbnail" style="border-radius: 50%;">
                            <a href='/home/{{ $musician->username }}'>
                                <img src="/storage/{{ $musician->pp }}" width='150px' height='150px' alt=''>
                            </a>
                        </div>
                        <h6 style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            {{ $musician->name }}
                        </h6>
                        {{-- <h6 style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            <small>{{ $musician->username }}</small>
                        </h6> --}}
                        {{ $position }}
                        {{-- {{ $fBtn }} --}}
                    </center>
                </span>

                <!-- The actual snackbar for following message -->
                <div id='checker'>You must have bought atleast 1 song by that Musician</div>
            @endforeach
        </div>
        <!-- ****** Artists Area End ****** -->
        <br>

        <!-- ****** Songs Area ****** -->
        <h5>Songs</h5>
        <div>
            @if($chart == 'newlyReleased')
                @php
                    $trendingVids = array(0 => 0);
                @endphp
            @endif
            @foreach($trendingVids as $vsong_bought => $downloads)
                @php
                    $fade = "black";
                @endphp
                @if($chart == 'newlyReleased')
                    @php
                        $vsong_bought = "";
                        $dThisWeek = "";
                    @endphp
                @else
                    @php
                        $dThisWeek = "<span style='font-size: 1rem; color: green;'>&#x2022;</span> <span
                            style='color: green;'>$downloads</span>";
                        $fadeFetch = $videoChart->where('video_id', $vsong_bought)->first();
                        $fadeDate = time() - strtotime($fadeFetch->created_at);
                        $fadeDate = $fadeDate/86400;
                    @endphp
                    @if($fadeDate > 7)
                        @php
                            $fade = "lightgrey";
                        @endphp
                    @endif
                @endif
                {{-- Get songs --}}
                @php
                    $squer = Videos::whereRaw('username != "" ' . $ANDvGenre . ' ' . $ANDvSong_id . ' ' .
                    $vsong_bought)->orderBy('video_id',
                    'desc')->get();
                @endphp
                @foreach($squer as $video)
                    @php
                        /* Check if song is in cart */
                        $cartVideoQuery = CartVideos::where('video_id',
                        $video->video_id)->where('username', $user->username)->count();
                        /* Check if song is bought */
                        $boughtVideoQuery = BoughtVideos::where('username',
                        $user->username)->where('video_id', $video->video_id)->count();
                        if ($cartVideoQuery > 0) {
                        $cart = Form::button("
                        <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                        </svg>",
                        ['class' => 'btn btn-light mb-1', 'style' => 'min-width: 90px; height: 33px;']);
                        $bbtn = Form::submit("buy", ['class' => 'btn mysonar-btn green-btn']);
                        } else {
                        if ($boughtVideoQuery > 0) {
                        $cart = "";
                        $bbtn = Form::button("Owned
                        <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                        </svg>",
                        ['class' => 'btn btn-sm btn-light']);
                        } else {
                        $cart = Form::button("
                        <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                        </svg>",
                        ['type' => 'submit', 'class' => 'mysonar-btn mb-1']);
                        $bbtn = Form::submit("buy", ['class' => 'btn mysonar-btn green-btn']);
                        }
                        }
                    @endphp
                    @if($boughtVideoQuery == 0)
                        <span class="card m-1 pb-2"
                            style='border-radius: 10px; display: inline-block; text-align: center;'>
                            <div class="thumbnail" style="border-top-left-radius: 10px; border-top-right-radius: 10px;">
                                <a href='/charts/{{ $video->video_id }}'>
                                    <img src='/storage/{{ $video->video_thumbnail }}' width="160em" height="90em">
                                </a>
                            </div>
                            <h6
                                style='padding: 10px 5px 0 5px; margin: 0px; width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                {{ $video->video_name }}</h6>
                            <h6 style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>
                                <small>{{ $video->username }} {{ $video->ft }}</small>
                            </h6>
                            <h6>
                                <small style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>
                                    {{ $video->bought_videos->count() }} Downloads
                                </small>
                            </h6>
                            {{-- Add song to cart --}}
                            {!!Form::open(['action' => 'CartVideosController@store',
                            'method'
                            => 'POST'])!!}
                            {{ Form::hidden('cart-video-song', $video->video_id) }}
                            {{ Form::hidden('to', 'charts/' . $chart . '/' . $vGenre) }}
                            {{ $cart }}
                            {!!Form::close()!!}
                            {{-- Buy song --}}
                            {!!Form::open(['action' => 'CartVideosController@store',
                            'method'
                            => 'POST'])!!}
                            {{ Form::hidden('cart-video-song', $video->video_id) }}
                            {{ Form::hidden('to', 'cart') }}
                            {{ $bbtn }}
                            {!!Form::close()!!}
                        </span>
                    @endif
                @endforeach
            @endforeach
        </div>
        <!-- ****** Songs Area End ****** -->
        <!-- End of Chart Area -->
    </div>
</div>

{{-- For mobile --}}
<div class="row anti-hidden">
    <div class="col-sm-12">
        <div class="p-2">
            <h5>Artists</h5>
            <div class="hidden-scroll border-bottom">
                @foreach($trendingArtists as $trendingArtist => $userDownloads)
                    @if($chart == 'trending')
                        @if($trendingArtist == $winner)
                            @php
                                $position = "<h6 style='background-color: green;'>
                                    <small style='color: white;'>Top</small>
                                </h6>
                                ";
                            @endphp
                        @elseif(array_key_exists($trendingArtist, $referralList))
                            @php
                                $position = "<h6 style='background-color: green;'>
                                    <small style='color: white;'>$userDownloads Downloads</small>
                                </h6>";
                            @endphp
                        @else
                            @php
                                $position = "<h6 style='background-color: orange;'>
                                    <small style='color: white;'>$userDownloads Downloads</small>
                                </h6>";
                            @endphp
                        @endif
                    @else
                        @php
                            $position = "";
                        @endphp
                    @endif
                    @php
                        $musician = User::where('username', $trendingArtist)->first();
                        $followQuery = Follow::where('followed', $trendingArtist)->where('username',
                        $user->username)->count();
                        $boughtVideosQuery = BoughtVideos::where('username',
                        $user->username)->where('bought_video_artist', $trendingArtist)->count();
                        if ($followQuery == 0) {
                        if ($boughtVideosQuery > 0 || $user->username == '@blackmusic') {
                        $fBtn =
                        Form::submit('follow', ['class' => 'mysonar-btn']);
                        } else {
                        $fBtn = Form::button('follow', ['class' => 'mysonar-btn', 'onclick' =>
                        'checkerSnackbar()']);
                        }
                        } else {
                        $fBtn = Form::button("
                        Followed
                        <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                        </svg>",
                        ['type' => 'submit', 'class' => 'btn btn-light']);
                        }
                    @endphp
                    <span class="pt-0 pl-0 pr-0 pb-2" style='border-radius: 10px'>
                        <center>
                            <div class="card avatar-thumbnail" style="border-radius: 50%;">
                                <a href='/home/{{ $musician->username }}'>
                                    <img src="/storage/{{ $musician->pp }}" width='150px' height='150px' alt=''>
                                </a>
                            </div>
                            <h6 class="p-0 m-0"
                                style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                {{ $musician->name }}
                            </h6>
                            {{-- <h6 class="p-0 mt-0 mr-0 ml-0" style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            <small>{{ $musician->username }}</small>
                            </h6> --}}
                            {{ $position }}
                            {{-- {{ $fBtn }} --}}
                        </center>
                    </span>

                    <!-- The actual snackbar for following message -->
                    <div id='checker'>You must have bought atleast 1 song by that Musician</div>
                @endforeach
                <br>
                <br>
            </div>
            {{-- Artists Area end --}}

            {{-- Songs area start --}}
            @if($chart == 'newlyReleased')
                @php
                    $trendingVids = array(0 => 0);
                @endphp
            @endif
            @foreach($trendingVids as $vsong_bought => $downloads)
                @php
                    $fade = "black";
                @endphp
                @if($chart == 'newlyReleased')
                    @php
                        $vsong_bought = "";
                        $dThisWeek = "";
                    @endphp
                @else
                    @php
                        $dThisWeek = "<span style='font-size: 1rem; color: green;'>&#x2022;</span> <span
                            style='color: green;'>$downloads</span>";
                        $fadeFetch = $videoChart->where('video_id', $vsong_bought)->first();
                        $fadeDate = time() - strtotime($fadeFetch->created_at);
                        $fadeDate = $fadeDate/86400;
                    @endphp
                    @if($fadeDate > 7)
                        @php
                            $fade = "lightgrey";
                        @endphp
                    @endif
                @endif
                {{-- Get songs --}}
                @php
                    $squer = Videos::whereRaw('username != "" ' . $ANDvGenre . ' ' . $ANDvSong_id . ' ' .
                    $vsong_bought)->orderBy('video_id',
                    'desc')->get();
                @endphp
                @foreach($squer as $video)
                    @php
                        /* Check if song is in cart */
                        $cartVideoQuery = CartVideos::where('video_id',
                        $video->video_id)->where('username', $user->username)->count();
                        /* Check if song is bought */
                        $boughtVideoQuery = BoughtVideos::where('username',
                        $user->username)->where('video_id', $video->video_id)->count();
                    @endphp
                    @if($cartVideoQuery > 0)
                        @php
                            $cart = "<button class='btn btn-light mb-1' style='min-width: 40px; height: 33px;'>
                                <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16'
                                    fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                    <path fill-rule='evenodd'
                                        d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                                </svg>";
                                $bbtn = "<button class='btn mysonar-btn green-btn float-right'>buy</button>";
                        @endphp
                    @else
                        @if($boughtVideoQuery > 0)
                            @php
                                $cart = "";
                                $bbtn = "<button class='btn btn-sm btn-light float-right'>Owned
                                    <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16'
                                        fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                        <path fill-rule='evenodd'
                                            d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                                    </svg>";
                            @endphp
                        @else
                            @php
                                $cart = "<button class='mysonar-btn mb-1' style='min-width: 40px;'>
                                    <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16'
                                        fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                        <path fill-rule='evenodd'
                                            d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                                    </svg>";
                                    $cForm = "";
                                    $bbtn = "<button class='btn mysonar-btn green-btn float-right'>buy</button>";
                                    $dForm = "";
                            @endphp
                        @endif
                    @endif
                    @if($boughtVideoQuery == 0)
                        <div class="media p-2 border-bottom">
                            <div class="media-left thumbnail">
                                <a href='/charts/{{ $video->video_id }}'>
                                    <img src='/storage/{{ $video->video_thumbnail }}' width="160em" height="90em">
                                </a>
                            </div>
                            <div class="media-body ml-2">
                                <h6 class="m-0"
                                    style='width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                    {{ $video->video_name }}</h6>
                                <h6 class="m-0">
                                    <small>{{ $video->username }} {{ $video->ft }}</small>
                                </h6>
                                <h6>
                                    <small class="m-0">
                                        {{ $video->bought_videos->count() }} Downloads
                                    </small>
                                </h6>
                                {{-- Add song to cart --}}
                                {!!Form::open(['id' => 'video-cart-form' . $video->video_id, 'action' =>
                                'CartVideosController@store',
                                'method' => 'POST'])!!}
                                {{ Form::hidden('cart-video-song', $video->video_id) }}
                                {{ Form::hidden('to', 'charts/' . $chart . '/' . $vGenre) }}
                                {!!Form::close()!!}
                                {{-- Buy song --}}
                                {!!Form::open(['id' => 'video-buy-form' . $video->video_id, 'action' =>
                                'CartVideosController@store',
                                'method' => 'POST'])!!}
                                {{ Form::hidden('cart-video-song', $video->video_id) }}
                                {{ Form::hidden('to', 'cart') }}
                                {!!Form::close()!!}
                                <a href='#' style="color: #000;"
                                    onclick='event.preventDefault();
													 document.getElementById("{{ 'video-cart-form' . $video->video_id }}").submit();'>
                                    {!! $cart !!}
                                </a>
                                <a href='#' style="color: #000;"
                                    onclick='event.preventDefault();
													 document.getElementById("{{ 'video-buy-form' . $video->video_id }}").submit();'>
                                    {!! $bbtn !!}
                                </a>
                            </div>
                        </div>
                    @endif
                @endforeach
            @endforeach
        </div>
    </div>
</div>
@include('inc/bottomnav')
@endsection
