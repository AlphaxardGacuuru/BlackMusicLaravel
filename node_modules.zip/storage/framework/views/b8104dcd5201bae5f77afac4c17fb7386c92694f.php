

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-4"></div>
    <div style="text-align: center;" class="col-sm-4">
        

        <!-- Profile Pic Form -->
        <br id="pp">
        <hr>
        <br>
        <div class="contact-form form-group">
            <h1>UPDATE PASSWORD</h1>
            <br>
            <?php echo Form::open(['action' => ['HomeController@update', Auth::user()->user_id], 'method' => 'POST', 'enctype'
            => 'multipart/form-data']); ?>

            <?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => 'New Password'])); ?>

            <br>
            <?php echo e(Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Confirm Password'])); ?>

            <br>
            <?php if(Auth::user()->acc_type == 'musician'): ?>
                <h1>UPDATE WITHDRAWAL AMOUNT</h1>
                <?php echo e(Form::text('withdrawal', null, ['class' => 'form-control', 'placeholder' => 'KES ' . Auth::user()->withdrawal])); ?>

                <br>
            <?php else: ?>
                <h1>BECOME A MUSICIAN</h1>
                <br>
                <h6><?php echo e(Form::radio('acc-type', 'musician')); ?> I'm a
                    musician</h6>
                <br>
                <br>
                <br>
            <?php endif; ?>
            <?php echo e(Form::hidden('_method', 'PUT')); ?>

            <?php echo e(Form::hidden('to', 'settings')); ?>

            <?php echo e(Form::reset('reset', ['class' => 'sonar-btn'])); ?>

            <br class="anti-hidden">
            <br class="anti-hidden">
            <?php echo e(Form::submit('save changes', ['class' => 'sonar-btn'])); ?>

            <?php echo Form::close(); ?>

        </div>
        <!-- Profile Pic Form End -->

        <!-- Deactivate Area -->
        <!-- Modal for Deactivating Account -->
        <div id="deleteModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title"><b style="color: red;">WARNING</b> Account Deactivation!</h4>
                        <button type="button" style="float: right;" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <h4>Are you sure you want to <b>DEACTIVATE</b> your <b>Black Music Account</b>.</h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Cancel</button>
                        <form action="deactivate.php" method="POST">
                            <button type="submit" style="float: left;" class="btn btn-sm btn-danger"
                                name="Deactivate">Deactivate</button>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <br>
        <hr>
        <br>

        <!-- single accordian area -->
        
        <div class="col-sm-4"></div>
    </div>
    <!-- End of Deactivate Area -->
</div>
<div class="col-sm-4"></div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/settings.blade.php ENDPATH**/ ?>