

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Preloader Start -->
<div id="preloader">
    <div class="preload-content">
        <div id="sonar-load"></div>
    </div>
</div>
<!-- Preloader End -->

<!-- Grids -->
<div class="grids d-flex justify-content-between">
    <div class="grid1"></div>
    <div class="grid2"></div>
    <div class="grid3"></div>
    <div class="grid4"></div>
    <div class="grid5"></div>
    <div class="grid6"></div>
    <div class="grid7"></div>
    <div class="grid8"></div>
    <div class="grid9"></div>
</div>

<br>
<br>
<br>
<br>

<!-- ***** Call to Action Area Start ***** -->
<div class="sonar-call-to-action-area section-padding-0-100">
    <div class="backEnd-content">
        <h2>Studio</h2>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="contact-form text-center call-to-action-content wow fadeInUp" data-wow-delay="0.5s">
                    <h2>Upload your song</h2>
                    <h5>It's free</h5>
                    <br>
                    <div class="form-group">
                        <?php echo Form::open(['action' => 'VideosController@store', 'method' => 'POST', 'enctype' =>
                        'multipart/form-data']); ?>

                        <br>
                        <?php echo e(Form::text('video', '', ['class' => 'form-control', 'placeholder' => 'Video URL from Youtube', 'required'])); ?>

                        <br>
                        <br>
                        <small class="error"> </small>
                        <?php echo e(Form::text('video-name', '', ['class' => 'form-control', 'placeholder' => 'Song name', 'required'])); ?>

                        <br>
                        <small class="error"> </small>
                        <?php echo e(Form::text('ft', '', ['class' => 'form-control', 'placeholder' => 'Featuring Artist'])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::select('video-genre', [
								 'Afro'=> 'Afro',
								 'Benga' => 'Benga',
								 'Blues' => 'Blues',
								 'Boomba' => 'Boomba',
								 'Country' => 'Country',
								 'Cultural' => 'Cultural',
								 'EDM' => 'EDM',
								 'Genge' => 'Genge',
								 'Gospel' => 'Gospel',
								 'Hiphop' => 'Hiphop',
								 'Jazz' => 'Jazz',
								 'Music of Kenya' => 'Music of Kenya',
								 'Pop' => 'Pop',
								 'R&B' => 'R&B',
								 'Rock' => 'Rock',
								 'Sesube' => 'Sesube',
								 'Taarab' => 'Taarab'
								 ], null, ['class' => 'form-control', 'placeholder' => 'Select song genre', 'required'])); ?>

                        <br>
                        <br>
                        <small class="error"> </small>
                        <?php echo e(Form::file('vArt', ['class' => 'form-control', 'accept' => 'image/*', 'required'])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'cols' => '30', 'rows' => '10', 'placeholder' => 'Say something about your song', 'required'])); ?>

                        <br>
                        <!-- single accordian area -->
                        <div class="panel single-accordion">
                            <h6>
                                <a role="button" class="collapsed" aria-expanded="true" aria-controls="collapseTwo"
                                    data-parent="#accordion" data-toggle="collapse" href="#collapseTwo">UPLOAD VIDEO
                                    <span class="accor-open"><i class="fa fa-plus" aria-hidden="true"></i></span>
                                    <span class="accor-close"><i class="fa fa-minus" aria-hidden="true"></i></span>
                                </a>
                            </h6>
                            <div id="collapseTwo" class="accordion-content collapse">
                                <br>
                                <h3>Before you upload</h3>
                                <ol>
                                    <li>
                                        <h6>By uploading you agree that you <b>own</b> this song.</h6>
                                    </li>
                                    <li>
                                        <h6>Songs are sold at <b style="color: green;">kes 20</b>, Black Music takes
                                            <b style="color: green;">50% (kes 10)</b> and the musician takes <b
                                                style="color: green;">50% (kes 10)</b>.</h6>
                                    </li>
                                    <li>
                                        <h6>You will be paid <b>weekly</b>, via Mpesa to <b
                                                style='color: dodgerblue;'></b>.</h6>
                                    </li>
                                </ol>
                                <br>
                                <?php echo e(Form::submit('upload video', ['class' => 'sonar-btn'])); ?>

                            </div>
                        </div>
                        <br>
                        <br>
                        <?php echo e(Form::reset('reset', ['class' => 'sonar-btn'])); ?>

                        <?php echo Form::close(); ?>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views//pages/video-create.blade.php ENDPATH**/ ?>