

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Preloader Start -->
<div id="preloader">
    <div class="preload-content">
        <div id="sonar-load"></div>
    </div>
</div>
<!-- Preloader End -->

<!-- Grids -->
<div class="grids d-flex justify-content-between">
    <div class="grid1"></div>
    <div class="grid2"></div>
    <div class="grid3"></div>
    <div class="grid4"></div>
    <div class="grid5"></div>
    <div class="grid6"></div>
    <div class="grid7"></div>
    <div class="grid8"></div>
    <div class="grid9"></div>
</div>

<br>
<br>
<br>
<br class="hidden">

<!-- ***** Call to Action Area Start ***** -->
<div class="sonar-call-to-action-area section-padding-0-100">
    <div class="backEnd-content">
        <h2>Studio</h2>
    </div>
    <div class="row">
        <div class="col-sm-12">
            <center>
                <a href="/videos/create" class="btn sonar-btn">upload song</a>
            </center>
        </div>
    </div>
    <br>
    <div class="row">
        <div class="col-sm-2">
            <table class='table'>
                <tr>
                    <th style="border: none;">
                        <h5>Songs</h5>
                    </th>
                    <th style="border: none;">
                        <h5><?php echo e($videos->count()); ?></h5>
                    </th>
                </tr>
                <tr>
                    <td>
                        <h5>Downloads</h5>
                    </td>
                    <td>
                        <h5><?php echo e($downloads); ?></h5>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h6>Unpaid</h6>
                    </td>
                    <td>
                        <?php
                            $payoutSum = $payouts / 10;
                            $thisWeekDown = $downloads - $payoutSum;
                            $totalRevenue = $payoutSum * 10;
                            $thisWeekRev = $totalRevenue - $payoutSum;
                        ?>
                        <h6><?php echo e($thisWeekDown); ?></h6>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h5>Revenue</h5>
                    </td>
                    <td>
                        <h5 style='color: green;'>KES <?php echo e($totalRevenue); ?></h5>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h6>Unpaid</h6>
                    </td>
                    <td>
                        <h6 style='color: green;'>KES <?php echo e($thisWeekRev); ?></h6>
                    </td>
                </tr>
            </table>
        </div>

        <div class="col-sm-10">
            <table class="table table-responsive table-hover">
                <tr>
                    <th>
                        <h5>Song</h5>
                    </th>
                    <th>
                        <h5>Artist</h5>
                    </th>
                    <th>
                        <h5>ft</h5>
                    </th>
                    <th>
                        <h5>Genre</h5>
                    </th>
                    <th>
                        <h5>Downloads</h5>
                    </th>
                    <th>
                        <h5 style="color: green;">Revenue</h5>
                    </th>
                    <th>
                        <h5>Likes</h5>
                    </th>
                    <th>
                        <h5>Date</h5>
                    </th>
                    <th>
                        <h5></h5>
                    </th>
                </tr>
                <?php if(count($videos) > 0): ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><a href='/charts/<?php echo e($video->video_id); ?>'><?php echo e($video->video_name); ?></a></td>
                            <td><?php echo e($video->username); ?></td>
                            <td><?php echo e($video->ft); ?></td>
                            <td><?php echo e($video->genre); ?></td>
                            <td><?php echo e($video->bought_videos->count()); ?></td>
                            <td style='color: green;'>KES <?php echo e($video->bought_videos->count() * 10); ?></td>
                            <td><?php echo e($video->vsong_loves); ?></td>
                            <td><?php echo e($video->date); ?></td>
                            <td><a href='/videos/<?php echo e($video->video_id); ?>/edit'>
                                    <button class='mysonar-btn'>edit</button>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </table>

        </div>
    </div>
</div>

<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views//pages/studio.blade.php ENDPATH**/ ?>