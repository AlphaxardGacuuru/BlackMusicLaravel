
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        
        <br id="pp">
        <hr>
        <br>
        <div class="contact-form form-group">
            <center>
                <h1>EDIT PROFILE</h1>
                <br>
                
        <?php echo Form::open(['action' => ['HomeController@update', Auth::user()->user_id], 'method' => 'POST',
        'enctype' => 'multipart/form-data']); ?>

        <br>
        <?php echo e(Form::label('pp', 'Profile Pic', ['class' => 'float-left'])); ?>

        <?php echo e(Form::file('profile-pic', ['class' => 'form-control'])); ?>

        <br>
        <?php echo e(Form::label('name', 'Name', ['class' => 'float-left'])); ?>

        <?php echo e(Form::text('name', null, ['class' => 'form-control', 'placeholder' => Auth::user()->name])); ?>

        <br>
        <?php echo e(Form::label('email', 'Email', ['class' => 'float-left'])); ?>

        <?php echo e(Form::text('email', null, ['class' => 'form-control', 'placeholder' => Auth::user()->email])); ?>

        <br>
        <?php echo e(Form::label('bio', 'Bio', ['class' => 'float-left'])); ?>

        <?php echo e(Form::text('bio', null, ['class' => 'form-control', 'placeholder' => Auth::user()->bio])); ?>

        
        <br>
        <?php echo e(Form::hidden('_method', 'PUT')); ?>

        <?php echo e(Form::hidden('to', 'edit')); ?>

        <?php echo e(Form::reset('reset', ['class' => 'sonar-btn'])); ?>

        <br class="anti-hidden">
        <br class="anti-hidden">
        <?php echo e(Form::submit('save changes', ['class' => 'sonar-btn'])); ?>

        <?php echo Form::close(); ?>

        </center>
    </div>
</div>
<div class="col-sm-4"></div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/profile-edit.blade.php ENDPATH**/ ?>