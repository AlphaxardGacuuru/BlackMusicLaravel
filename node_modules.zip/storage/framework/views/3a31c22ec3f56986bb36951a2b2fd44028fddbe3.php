<?php $__env->startComponent('mail::message'); ?>
    # Welcome to Black Music

    Hi there $username, welcome to Black Music. Check out your favorite musicians and support them by buying.

    

    Thanks,
    <?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/emails/welcome.blade.php ENDPATH**/ ?>