
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <br>
        <br>
        <br>
        <br>
        <center>
            <h2>Create your account</h2>
            <?php echo Form::open(['action' => 'UserController@store', 'method' => 'POST', 'class' => 'contact-form']); ?>

            <?php echo e(Form::text('username', '', ['class' => 'form-control', 'placeholder' => 'Username', 'required'])); ?>

            <br>
            <?php echo e(Form::text('phone', '', ['class' => 'form-control', 'placeholder' => 'Phone', 'required'])); ?>

            <br>
            <?php echo e(Form::submit('create', ['class' => 'sonar-btn'])); ?>

            <?php echo Form::close(); ?>

        </center>
    </div>
    <div class="col-sm-4"></div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views//auth/social.blade.php ENDPATH**/ ?>