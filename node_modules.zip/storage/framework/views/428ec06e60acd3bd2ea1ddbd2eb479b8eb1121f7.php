

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h1><?php echo e($title); ?></h1>
<?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' =>
'multipart/form-data']); ?>

<?php echo e(Form::textarea('body', '', ['class' => 'form-control', 'placeholder' => "What's on your mind"])); ?>

<div class="form-group">
    <?php echo e(Form::file('cover_image')); ?>

</div>
<div class="form group float-right">
    <?php echo e(Form::submit('post', ['class' => 'btn mysonar-btn'])); ?>

</div>
<br>
<a><span style="padding-left: 1%;" class="fa fa-image"></span></a>
<a><span style="padding-left: 1%;" class="fa fa-align-left"></span></a>
<br>
<br>
<h6>Poll</h6>
<label>
    <input type='text' name='poll_1' class='form-control' placeholder='Parameter 1' oninput='inputPara2()'
        onkeypress='return AvoidSpace(event)'>
</label>
<label id='para-2'></label>
<label id='para-3'></label>
<label id='para-4'></label>
<label id='para-5'></label>
<?php echo Form::close(); ?>

<br>
<br>
<?php echo $__env->make('layouts/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/discover.blade.php ENDPATH**/ ?>