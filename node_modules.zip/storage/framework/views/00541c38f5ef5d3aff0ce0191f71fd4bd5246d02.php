<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="theme-color" content="#232323" />
    
    <meta name="apple-mobile-web-app-status-bar-style" content="#232323">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Black Music')); ?></title>

    <!-- Favicon  -->
    <link rel="icon" href="img/havi logos-4.png">


    <!-- Scripts -->
    

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/black_music.css')); ?>">

    
    <link rel="manifest" href="manifest.webmanifest">
</head>
<body>
    <?php echo $__env->yieldContent('content'); ?>

    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
            <?php echo $__env->make('inc/messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-sm-4"></div>
    </div>

    <!-- ***** Footer Area Start ***** -->
    <footer class="footer-area">
        <!-- back end content -->
        <div class="backEnd-content">
            <img class="dots" src="img/core-img/dots.png" alt="">
            <h2>Black</h2>
        </div>

        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Copywrite Text -->
                    <div class="copywrite-text">
                        <p>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                            Copyright &copy;<script>
                                document.write(new Date().getFullYear());

                            </script> All rights reserved | This template is made with <i class="fa fa-heart-o"
                                aria-hidden="true"></i> by <a href="https://colorlib.com" target="_blank">Colorlib</a>
                            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- ***** Footer Area End ***** -->

    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="<?php echo e(asset('js/jquery/jquery-2.2.4.min.js')); ?>"></script>
    <!-- Popper js -->
    
    
    <!-- Bootstrap js -->
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <!-- Plugins js -->
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    <!-- Active js -->
    <script src="<?php echo e(asset('js/active.j')); ?>s"></script>

    <!-- Black Music JS -->
    <script src="<?php echo e(asset('js/black_music.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/layouts/app.blade.php ENDPATH**/ ?>