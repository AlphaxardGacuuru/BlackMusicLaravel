<?php
    use App\BoughtVideos;
    use App\VideoLikes;
    use App\Videos;
    use App\Follow;
    use App\CartVideos;
    use App\User;
?>


<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br class="hidden">
<?php
/* Function for adding into an array */
function array_push_assoc($array, $key, $value){
 $array[$key] = $value;
 return $array;
}
  $newlyClass = $trendClass = $topDownClass = $topLovedClass = $orderBy = $boughtVideo = $minDate = $artistsWHERE = "";
    if ($chart == 'newlyReleased') {
      $downloads = Videos::get();
      $minDate = 30;
      $orderBy = 'video_id';
      $ANDvSong_id = '';
      $newlyClass = "class='active-scrollmenu'";
    } elseif ($chart == 'trending') {
      $downloads = BoughtVideos::get();
      $minDate = 7;
      $orderBy = 'video_id';
      $ANDvSong_id = 'AND vsong_id =';
      $trendClass = "class='active-scrollmenu'";
    } elseif ($chart == 'topDownloaded') {
      $downloads = BoughtVideos::get();
      $minDate = 1000;
      $orderBy = 'vsong_downloads';
      $ANDvSong_id = 'AND vsong_id =';
      $topDownClass = "class='active-scrollmenu'";
    } elseif ($chart == 'topLoved') {
      $downloads = VideoLikes::get();
      $minDate = 100;
      $orderBy = 'vsong_loves';
      $ANDvSong_id = 'AND vsong_id =';
      $topLovedClass = "class='active-scrollmenu'";
    } 

  $AllClass = $AfroClass = $BengaClass = $BluesClass = $BoombaClass = $CountryClass = $CulturalClass = $EDMClass = $GengeClass = $GospelClass = $HiphopClass = $JazzClass = $MoKClass = $PopClass = $RandBClass = $RockClass = $SesubeClass = $TaarabClass = "";
    if ($vGenre == 'All') {
      $ANDvGenre = "";
      $AllClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Afro') {
      $ANDvGenre = 'AND vgenre = "Afro"';
      $AfroClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Benga') {
      $ANDvGenre = 'AND vgenre = "Benga"';
      $BengaClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Blues') {
      $ANDvGenre = 'AND vgenre = "Blues"';
      $BluesClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Boomba') {
      $ANDvGenre = 'AND vgenre = "Boomba"';
      $BoombaClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Country') {
      $ANDvGenre = 'AND vgenre = "Country"';
      $CountryClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Cultural') {
      $ANDvGenre = 'AND vgenre = "Cultural"';
      $CulturalClass = "class='active-scrollmenu'";
    }elseif ($vGenre == 'EDM') {
      $ANDvGenre = 'AND vgenre = "EDM"';
      $EDMClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Genge') {
      $ANDvGenre = 'AND vgenre = "Genge"';
      $GengeClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Gospel') {
      $ANDvGenre = 'AND video_genre = "Gospel"';
      $GospelClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Hiphop') {
      $ANDvGenre = 'AND video_genre = "Hiphop"';
      $HiphopClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Jazz') {
      $ANDvGenre = 'AND vgenre = "Jazz"';
      $JazzClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'MoK') {
      $ANDvGenre = 'AND vgenre = "Music of Kenya"';
      $MoKClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Pop') {
      $ANDvGenre = 'AND vgenre = "Pop"';
      $PopClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'RandB') {
      $ANDvGenre = 'AND vgenre = "R&B"';
      $RandBClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Rock') {
      $ANDvGenre = 'AND vgenre = "Rock"';
      $RockClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Sesube') {
      $ANDvGenre = 'AND vgenre = "Sesube"';
      $SesubeClass = "class='active-scrollmenu'";
    } elseif ($vGenre == 'Taarab') {
      $ANDvGenre = 'AND vgenre = "Taarab"';
      $TaarabClass = "class='active-scrollmenu'";
    }
?>

<!-- Scroll menu -->
<div id="chartsMenu" class="hidden-scroll" style="margin: 10px 0 0 0;">
    <span><a href="/charts/newlyReleased/All">
            <h5 <?php echo $newlyClass; ?>>Newly Released</h5>
        </a></span>
    <span><a href="/charts/trending/All">
            <h5 <?php echo $trendClass; ?>>Trending</h5>
        </a></span>
    <span><a href="/charts/topDownloaded/All">
            <h5 <?php echo $topDownClass; ?>>Top Downloaded</h5>
        </a></span>
    <span><a href="/charts/topLoved/All">
            <h5 <?php echo $topLovedClass; ?>>Top Loved</h5>
        </a></span>
</div>

<div id="chartsMenu" class="hidden-scroll" style="margin: 0 0 0 0;">
    <span>
        <a href="/charts/<?php echo $chart; ?>/All">
            <h6 <?php echo $AllClass; ?>>All</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Afro">
            <h6 <?php echo $AfroClass; ?>>Afro</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Benga">
            <h6 <?php echo $BengaClass; ?>>Benga</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Blues">
            <h6 <?php echo $BluesClass; ?>>Blues</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Boomba">
            <h6 <?php echo $BoombaClass; ?>>Boomba</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Country">
            <h6 <?php echo $CountryClass; ?>>Country</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Cultural">
            <h6 <?php echo $CulturalClass; ?>>Cultural</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/EDM">
            <h6 <?php echo $EDMClass; ?>>EDM</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Genge">
            <h6 <?php echo $GengeClass; ?>>Genge</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Gospel">
            <h6 <?php echo $GospelClass; ?>>Gospel</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Hiphop">
            <h6 <?php echo $HiphopClass; ?>>Hiphop</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Jazz">
            <h6 <?php echo $JazzClass; ?>>Jazz</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/MoK">
            <h6 <?php echo $MoKClass; ?>>Music of Kenya</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Pop">
            <h6 <?php echo $PopClass; ?>>Pop</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/RandB">
            <h6 <?php echo $RandBClass; ?>>R&B</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Rock">
            <h6 <?php echo $RockClass; ?>>Rock</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Sesube">
            <h6 <?php echo $SesubeClass; ?>>Sesube</h6>
        </a>
    </span>
    <span>
        <a href="/charts/<?php echo $chart; ?>/Taarab">
            <h6 <?php echo $TaarabClass; ?>>Taarab</h6>
        </a>
    </span>
</div>
<!-- End of scroll menu -->

<!-- Chart Area -->
<div class="row hidden">
    <div class="col-sm-12">

        <!-- ****** Artists Area Start ****** -->
        <h5>Artists</h5>
        <div class="hidden-scroll">
            <?php
                /*Get relevant songs*/
                /*Add to trend_week*/
                $trendWeek = strtotime("next Friday");
                $trendWeek = getdate($trendWeek);
                $dVar = $trendWeek[0];
                $trendingVids = array();
            ?>
            <?php $__currentLoopData = $downloads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $download): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    if ($chart == 'trending' || $chart == 'topDownloaded') {
                    $tDate = $dVar - strtotime($download->created_at);
                    $boughtVideo = $download->video_id;
                    } elseif ($chart == 'topLoved') {
                    $tDate = 0;
                    $boughtVideo = $lovedVideo;
                    } else {
                    $tDate = 0;
                    $boughtVideo = $download->video_id;
                    }
                    $tDate = $tDate/86400;
                ?>
                <?php if($tDate < $minDate): ?>
                    <?php if(array_key_exists($boughtVideo, $trendingVids)): ?>
                        <?php
                            $trendingVids[$boughtVideo] += 1;
                        ?>
                    <?php else: ?>
                        <?php
                            $trendingVids = array_push_assoc($trendingVids, $boughtVideo, 1);
                        ?>
                    <?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
                arsort($trendingVids);
                /* echo print_r($trendingVids) . '<br>' ;
                echo count($trendingVids) . "<br>"; */

                /*Create relevant array for artist*/
                $trendingArtists = array();
            ?>
            <?php $__currentLoopData = $trendingVids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boughtVideo => $downloads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $fetchArtist = Videos::where('video_id', $boughtVideo)->first();
                ?>
                <?php if(array_key_exists($fetchArtist->username, $trendingArtists)): ?>
                    <?php
                        $trendingArtists[$fetchArtist->username] += $downloads;
                    ?>
                <?php else: ?>
                    <?php
                        $trendingArtists = array_push_assoc($trendingArtists, $fetchArtist->username,
                        $downloads);
                    ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php
                arsort($trendingArtists);
                /* echo print_r($trendingArtists) . '<br>';
                echo count($trendingArtists) . "<br>"; */
            ?>

            
            <?php if($chart == 'trending'): ?>
                <?php
                    $referralList = array();
                ?>
                <?php $__currentLoopData = $trendingArtists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trendingArtist => $userDownloads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $referrals = Referrals::where('username', $trendingArtist)->get();
                        $referralCount = $referrals->count();
                    ?>
                    <?php if($referralCount >= 2): ?>
                        <?php for($i=0; $i < $referralCount; $i++): ?>
                            <?php
                                $rSongFetch = Videos::where('username', $referrals->referrer);
                            ?>
                            <?php if($rSongFetch): ?>
                                <?php if(array_key_exists($trendingArtist, $trendingArtists)): ?>
                                    <?php
                                        $referralList[$trendingArtist] +=1;
                                    ?>
                                <?php else: ?>
                                    <?php
                                        $referralList = array_push_assoc($referralList, $trendingArtist, 1);
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endfor; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php
                    arsort($referralList);
                    /* echo print_r($referralList) . '<br>' ; echo count($referralList)
                    . "<br>" ; echo key($referralList) . "<br>" ; */
                    $winner = key($referralList);
                ?>
            <?php endif; ?>

            
            <?php $__currentLoopData = $trendingArtists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trendingArtist => $userDownloads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($chart == 'trending'): ?>
                    <?php if($trendingArtist == $winner): ?>
                        <?php
                            $position = "<h6 style='background-color: green;'>
                                <small style='color: white;'>Top</small>
                            </h6>
                            ";
                        ?>
                    <?php elseif(array_key_exists($trendingArtist, $referralList)): ?>
                        <?php
                            $position = "<h6 style='background-color: green;'>
                                <small style='color: white;'>$userDownloads Downloads</small>
                            </h6>";
                        ?>
                    <?php else: ?>
                        <?php
                            $position = "<h6 style='background-color: orange;'>
                                <small style='color: white;'>$userDownloads Downloads</small>
                            </h6>";
                        ?>
                    <?php endif; ?>
                <?php else: ?>
                    <?php
                        $position = "";
                    ?>
                <?php endif; ?>
                <?php
                    $musician = User::where('username', $trendingArtist)->first();
                    $followQuery = Follow::where('followed', $trendingArtist)->where('username',
                    Auth::user()->username)->count();
                    $boughtVideosQuery = BoughtVideos::where('username',
                    Auth::user()->username)->where('bought_video_artist', $trendingArtist)->count();
                    if ($followQuery == 0) {
                    if ($boughtVideosQuery > 0 || Auth::user()->username == '@blackmusic') {
                    $fBtn =
                    Form::submit('follow', ['class' => 'mysonar-btn float-right']);
                    } else {
                    $fBtn = Form::button('follow', ['class' => 'mysonar-btn float-right', 'onclick' =>
                    'checkerSnackbar()']);
                    }
                    } else {
                    $fBtn = Form::button("
                    Followed
                    <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                        xmlns='http://www.w3.org/2000/svg'>
                        <path fill-rule='evenodd'
                            d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                    </svg>",
                    ['type' => 'submit', 'class' => 'btn btn-light float-right']);
                    }
                ?>
                <span>
                    <a href='#'>
                        <img src="/storage/<?php echo e($musician->pp); ?>" width='100px' height='100px' alt=''>
                    </a>
                    <h6 class='compress'
                        style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                        <?php echo e($musician->name); ?></h6>
                    <h6 style='width: 100px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                        <small><?php echo e($musician->username); ?></small></h6>
                    <?php echo e($position); ?>

                    <?php echo e($fBtn); ?>

                </span>

                <!-- The actual snackbar for following message -->
                <div id='checker'>You must have bought atleast 1 song by that Musician</div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- ****** Artists Area End ****** -->
        <br>
        <!-- ****** Songs Area ****** -->
        <h5>Songs</h5>
        <div>
            <?php if($chart == 'newlyReleased'): ?>
                <?php
                    $trendingVids = array(0 => 0);
                ?>
            <?php endif; ?>
            <?php $__currentLoopData = $trendingVids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vsong_bought => $downloads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $fade = "black";
                ?>
                <?php if($chart == 'newlyReleased'): ?>
                    <?php
                        $vsong_bought = "";
                        $dThisWeek = "";
                    ?>
                <?php else: ?>
                    <?php
                        $dThisWeek = "<span style='font-size: 1rem; color: green;'>&#x2022;</span> <span
                            style='color: green;'>$downloads</span>";
                        $fadeFetch = $downloads->where('video_id', $vsong_bought);
                        $fadeDate = time() - strtotime($vsong_bought_date);
                        $fadeDate = $fadeDate/86400;
                    ?>
                    <?php if($fadeDate > 7): ?>
                        <?php
                            $fade = "lightgrey";
                        ?>
                    <?php endif; ?>
                <?php endif; ?>
                
                <?php
                    $squer = Videos::whereRaw('username != "" ' . $ANDvGenre, $ANDvSong_id .
                    '"$vsong_bought"')->orderBy('video_id',
                    'desc')->get();
                ?>
                <?php $__currentLoopData = $squer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        /* Check if song is in cart */
                        $cartVideoQuery = CartVideos::where('video_id',
                        $video->video_id)->where('username', Auth::user()->username)->count();
                        /* Check if song is bought */
                        $boughtVideoQuery = BoughtVideos::where('username',
                        Auth::user()->username)->where('video_id', $video->video_id)->count();
                        if ($cartVideoQuery > 0) {
                        $cart = Form::button("
                        <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                        </svg>",
                        ['class' => 'btn btn-light mb-1', 'style' => 'min-width: 90px; height: 33px;']);
                        $bbtn = Form::submit("buy", ['class' => 'btn mysonar-btn green-btn']);
                        } else {
                        if ($boughtVideoQuery > 0) {
                        $cart = "";
                        $bbtn = Form::button("Owned
                        <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                        </svg>",
                        ['class' => 'btn btn-sm btn-light']);
                        } else {
                        $cart = Form::button("
                        <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16' fill='currentColor'
                            xmlns='http://www.w3.org/2000/svg'>
                            <path fill-rule='evenodd'
                                d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                        </svg>",
                        ['type' => 'submit', 'class' => 'mysonar-btn mb-1']);
                        $bbtn = Form::submit("buy", ['class' => 'btn mysonar-btn green-btn']);
                        }
                        }
                    ?>
                    <?php if($boughtVideoQuery == 0): ?>
                        <span class="card m-1 pb-2"
                            style='border-radius: 10px; display: inline-block; text-align: center;'>
                            <div class="thumbnail" style="border-top-left-radius: 10px; border-top-right-radius: 10px;">
                                <a href='play_video.php?video_id=video_id'>
                                    <img src='/storage/<?php echo e($video->video_thumbnail); ?>' width="160em" height="90em">
                                </a>
                            </div>
                            <h6
                                style='padding: 10px 5px 0 5px; margin: 0px; width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                <?php echo e($video->video_name); ?></h6>
                            <h6 style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>
                                <small><?php echo e($video->username); ?> <?php echo e($video->ft); ?></small>
                            </h6>
                            <h6>
                                <small style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>
                                    <?php echo e($video->bought_videos->count()); ?> Downloads
                                </small>
                            </h6>
                            
                            <?php echo Form::open(['action' => 'CartVideosController@store',
                            'method'
                            => 'POST']); ?>

                            <?php echo e(Form::hidden('cart-video-song', $video->video_id)); ?>

                            <?php echo e(Form::hidden('to', 'posts')); ?>

                            <?php echo e($cart); ?>

                            <?php echo Form::close(); ?>

                            
                            <?php echo Form::open(['action' => 'CartVideosController@store',
                            'method'
                            => 'POST']); ?>

                            <?php echo e(Form::hidden('cart-video-song', $video->video_id)); ?>

                            <?php echo e(Form::hidden('to', 'cart')); ?>

                            <?php echo e($bbtn); ?>

                            <?php echo Form::close(); ?>

                        </span>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <!-- ****** Songs Area End ****** -->
        <!-- End of Chart Area -->
    </div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/charts.blade.php ENDPATH**/ ?>