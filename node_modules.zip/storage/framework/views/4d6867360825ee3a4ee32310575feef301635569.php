
<?php $__env->startSection('content'); ?>
<h1><?php echo e($result); ?></h1>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/search.blade.php ENDPATH**/ ?>