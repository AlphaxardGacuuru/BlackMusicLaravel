
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br>
<br>
<br class="hidden">

<!-- Search Form End -->

<div class="row">
    <div class="col-sm-2">
        <!-- Number of Users Start-->
        <div class="card">
            <table class='table'>
                <tr>
                    <td>
                        <h4>Users</h4>
                    </td>
                    <td>
                        <?php echo e($users->count()); ?>

                    </td>
                </tr>
                <!-- Number of Users End -->

                <!-- Number of Musicians Start-->
                <tr>
                    <td>
                        <h4>Musicians</h4>
                    </td>
                    <td>
                        <?php echo e($users->where('acc_type', 'musician')->count() - 1); ?>

                    </td>
                </tr>
                <!-- Number of Musicians End -->

                <!-- Number of Songs Start -->
                <tr>
                    <td>
                        <h4>Songs</h4>
                    </td>
                    <td>
                        <?php echo e($videos->count()); ?>

                    </td>
                </tr>
                <!-- Number of Songs End -->

                <!-- Number of Songs Bought Start -->
                <tr>
                    <td>
                        <h4>Songs Bought</h4>
                    </td>
                    <td>
                        <?php echo e($boughtVideos->count()); ?>

                    </td>
                </tr>
                <!-- Number of Songs Bought End -->

                <!-- Revenue Start -->
                <tr>
                    <td>
                        <h4>Revenue</h4>
                    </td>
                    <td style="color: green;">
                        KES <?php echo e($boughtVideos->count() * 20); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <h6>this week</h6>
                    </td>
                    <td>
                        <?php
                            $sum = $boughtVideos->count() * 20;
                            $payoutSum = $payouts->sum('amount') * 2;
                            $payoutTotal = $sum-$payoutSum;
                        ?>
                        <h6>KES <?php echo e($payoutTotal); ?></h6>
                    </td>
                </tr>
                <!-- Revenue End -->

                <!-- Profit Start -->
                <tr>
                    <td>
                        <h4>Profit</h4>
                    </td>
                    <td style="color: green;">
                        KES <?php echo e($boughtVideos->count() * 10); ?>

                    </td>
                </tr>
                <tr>
                    <td>
                        <h6>this week</h6>
                    </td>
                    <td style="color: green;">
                        <?php
                            $sum = $boughtVideos->count() * 10;
                            $payoutSum = $payouts->sum('amount');
                            $payoutTotal = $sum-$payoutSum;
                        ?>
                        <h6>KES <?php echo e($payoutTotal); ?></h6>
                    </td>
                </tr>
            </table>
        </div>
        <!-- Profit End -->
        <br>
        <!-- <a href="admin_actions.php"><button class="sonar-btn">change</button></a> -->
    </div>
    <div class="col-sm-9">
        <!-- <div class="card"> -->
        <table class="table table-responsive table-hover">
            <tr>
                <td>User ID</td>
                <td>Name</td>
                <td>Username</td>
                <td>Email</td>
                <td>Phone</td>
                <td>Gender</td>
                <td>Acc Type</td>
                <td>Bio</td>
                <td>Deco</td>
                <td>DOB</td>
                <td>Location</td>
                <td>Audios Bought</td>
                <td>Videos Bought</td>
                <td>Date Joined</td>
            </tr>
            <?php
                $users = $users->limit(10)->get();
            ?>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->user_id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone); ?></td>
                    <td><?php echo e($user->gender); ?></td>
                    <td><?php echo e($user->acc_type); ?></td>
                    <td><?php echo e($user->bio); ?></td>
                    <td><?php echo e($user->deco); ?></td>
                    <td><?php echo e($user->dob); ?></td>
                    <td><?php echo e($user->location); ?></td>
                    <td><?php echo e($user->asongs_bought); ?></td>
                    <td><?php echo e($user->vsongs_bought); ?></td>
                    <td><?php echo e($user->date_joined); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <!-- </div> -->
    </div>
    <div class="col-sm-1"></div>
</div>
<div class="row">
    <div class="col-sm-2"></div>
    <div class="col-sm-9">
        <h1 style="text-align: center;">Song Payouts</h1>
        <br>
        <table class="table table-responsive table-hover">
            <tr>
                <th>Name</th>
                <th>Artist</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Minimum</th>
                <th>Amount</th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $sum = $boughtVideos->where('bought_video_artist', $user->username)->count() * 10;
                    $payoutSum = $payouts->where('username', $user->username)->sum('amount');
                    $payoutTotal = $sum-$payoutSum;
                    $phonenumber = substr_replace($user->phone,'0',0,-9);
                    if(preg_match( '/^(\d{4})(\d{3})(\d{3})$/', $phonenumber, $matches)) {
                    $phone = $matches[1] . ' ' .$matches[2] . ' ' . $matches[3];
                    }
                ?>
                <?php if($payoutTotal != 0): ?>
                    <tr>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($phone); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->withdrawal); ?></td>
                        <td>
                            
                            <?php echo Form::open(['action' => 'PayoutsController@store', 'method' => 'POST']); ?>

                            <?php echo e(Form::hidden('artist', $user->username)); ?>

                            <?php echo e(Form::hidden('amount', $payoutTotal)); ?>

                            <?php echo e(Form::submit('kes ' . $payoutTotal, ['class' => 'btn mysonar-btn green-btn'])); ?>

                            <?php echo Form::close(); ?>

                        </td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <div class="col-sm-1"></div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/admin.blade.php ENDPATH**/ ?>