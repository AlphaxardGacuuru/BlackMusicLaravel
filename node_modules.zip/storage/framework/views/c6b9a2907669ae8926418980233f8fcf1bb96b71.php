

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <div class="contact-form">
            <?php echo Form::open(['action' => 'PostCommentsController@store', 'method' => 'POST', 'enctype' =>
            'multipart/form-data']); ?>

            <div class="float-left">
                <a href="post-show">
                    <!-- Close Icon -->
                    <i style="font-size: 1.5em;" class="ti-close" aria-hidden="true"></i>
                </a>
            </div>
            <div class="form group float-right">
                <?php echo e(Form::submit('comment', ['class' => 'btn mysonar-btn'])); ?>

            </div>
            <?php echo e(Form::textarea('post_text', '', ['class' => 'form-control', 'placeholder' => "Reply"])); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>
    <div class="col-sm-4"></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/post-comment-create.blade.php ENDPATH**/ ?>