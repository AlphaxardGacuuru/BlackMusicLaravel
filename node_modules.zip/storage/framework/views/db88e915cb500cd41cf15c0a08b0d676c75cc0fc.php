<?php
    use App\Kopokopo;

    /* Create new post */
    $kopokopo = new Kopokopo;
    $kopokopo->sender_phone = auth()->user()->phone;
    $kopokopo->reference = "";
    $kopokopo->amount = 20;
    $kopokopo->last_name = "";
    $kopokopo->first_name = auth()->user()->name;
    $kopokopo->middle_name = "";
    $kopokopo->service_name = "";
    $kopokopo->business_number = "";
    $kopokopo->internal_transaction_id = "";
    $kopokopo->transaction_timestamp = "";
    $kopokopo->transaction_type = "";
    $kopokopo->account_number = "";
    $kopokopo->currency = "";
    $kopokopo->signature = "";
    $kopokopo->save();

?>
<?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/kopokopo.blade.php ENDPATH**/ ?>