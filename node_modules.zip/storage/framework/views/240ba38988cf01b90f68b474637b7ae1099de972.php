
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br>
<br>
<br>

<!-- ***** Call to Action Area Start ***** -->
<div class="sonar-call-to-action-area section-padding-0-100">
    <div class="backEnd-content">
        <h2>Studio</h2>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="contact-form text-center call-to-action-content wow fadeInUp" data-wow-delay="0.5s">
                    <h2>Edit <?php echo e($video->video_name); ?></h2>
                    <br>
                    <div class="form-group">
                        <?php echo Form::open(['action' => ['VideosController@update', $video->video_id], 'method' => 'POST',
                        'enctype' =>
                        'multipart/form-data']); ?>

                        <?php echo e(Form::hidden('_method', 'PUT')); ?>

                        <small class="error"> </small>
                        <?php echo e(Form::label('Video name', '', ['class' => 'float-left'])); ?>

                        <?php echo e(Form::text('video-name', '', ['class' => 'form-control', 'placeholder' => $video->video_name,
                       ])); ?>

                        <br>
                        <?php echo e(Form::label('Featuring Artist', '', ['class' => 'float-left'])); ?>

                        <?php echo e(Form::text('ft', '', ['class' => 'form-control', 'placeholder' => $video->ft])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::label('Video Genre', '', ['class' => 'float-left'])); ?>

                        <?php echo e(Form::select('video-genre', [
								 'Afro'=> 'Afro',
								 'Benga' => 'Benga',
								 'Blues' => 'Blues',
								 'Boomba' => 'Boomba',
								 'Country' => 'Country',
								 'Cultural' => 'Cultural',
								 'EDM' => 'EDM',
								 'Genge' => 'Genge',
								 'Gospel' => 'Gospel',
								 'Hiphop' => 'Hiphop',
								 'Jazz' => 'Jazz',
								 'Music of Kenya' => 'Music of Kenya',
								 'Pop' => 'Pop',
								 'R&B' => 'R&B',
								 'Rock' => 'Rock',
								 'Sesube' => 'Sesube',
								 'Taarab' => 'Taarab'
								 ], null, ['class' => 'form-control', 'placeholder' => $video->video_genre,])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::label('Video thumbnail', '', ['class' => 'float-left'])); ?>

                        <?php echo e(Form::file('vArt', ['class' => 'form-control', 'accept' => 'image/*'])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::label('Video description', '', ['class' => 'float-left'])); ?>

                        <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'cols' => '30', 'rows' => '10', 'placeholder' => $video->video_description])); ?>

                        <?php echo e(Form::submit('save changes', ['class' => 'sonar-btn'])); ?>

                        <br>
                        <br>
                        <?php echo e(Form::reset('reset', ['class' => 'sonar-btn'])); ?>

                        <?php echo Form::close(); ?>


                        <br>
                        <a href='/charts/<?php echo e($video->video_id); ?>' class="btn sonar-btn">go to song</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/video-edit.blade.php ENDPATH**/ ?>