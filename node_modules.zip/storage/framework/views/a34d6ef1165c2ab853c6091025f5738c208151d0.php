

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>
<br class="hidden">
<br class="hidden">
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <div class="p-2 border-bottom">
            <br>
            <h5>Library</h5>
        </div>
        <?php if(count($boughtVideos) > 0): ?>
            <?php $__currentLoopData = $boughtVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $boughtVideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="media p-2 border-bottom">
                    <div class="media-left thumbnail">
                        <a href='/charts/<?php echo e($boughtVideo->video_id); ?>'>
                            <img src='storage/<?php echo e($boughtVideo->videos->video_thumbnail); ?>' width="160em"
                                height="90em">
                        </a>
                    </div>
                    <div class="media-body ml-2">
                        <h6 class="m-0"
                            style='width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            <?php echo e($boughtVideo->videos->video_name); ?></h6>
                        <h6 class="m-0">
                            <small><?php echo e($boughtVideo->videos->username); ?>

                                <?php echo e($boughtVideo->videos->ft); ?></small>
                        </h6>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </div>
    <div class="col-sm-4"></div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views//pages/library.blade.php ENDPATH**/ ?>