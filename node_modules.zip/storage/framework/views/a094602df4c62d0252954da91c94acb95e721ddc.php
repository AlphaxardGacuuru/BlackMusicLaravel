<?php
    use App\Notifications;
    use App\DecoNotifications;
    use App\FollowNotifications;
    use App\VideoNotifications;
    use App\CartVideos;
?>
<?php if(auth()->guard()->guest()): ?>
    <?php
        class topnavGuest {
        /* Guest properties */
        public $name = 'Guest';
        public $username = '@guest';
        public $email;
        public $phone;
        public $gender;
        public $acc_type = 'normal';
        public $acc_type_2;
        public $pp = 'profile-pics/male_avatar.png';
        public $pb;
        public $bio;
        public $dob;
        public $decos = [1];
        public $location;
        public $withdrawal;
        }

        $user = new topnavGuest();
    ?>
<?php else: ?>
    <?php
        $user = Auth::user();
    ?>
<?php endif; ?>
<!-- Preloader Start -->

<!-- Preloader End -->

<!-- Grids -->


<!-- ***** Main Menu Area Start ***** -->
<div class="mainMenu d-flex align-items-center justify-content-between">
    <!-- Close Icon -->
    <div class="closeIcon">
        <i class="ti-close" aria-hidden="true"></i>
    </div>
    <!-- Logo Area -->
    <div class="logo-area">
        <a href="/posts">Black Music</a>
    </div>
    <!-- Nav -->
    <div class="sonarNav wow fadeInUp" data-wow-delay="1s">
        <nav>
            <ul>
                <li class='nav-item active'>
                    <a href='/posts' class='nav-link' style='color:<?php if(Route::is('posts.index')){echo 'gold';}?>;'>
                        <span style=' float: left; padding-right: 20px;'>
                            <svg class="bi bi-house" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                                <path fill-rule="evenodd"
                                    d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
                            </svg>
                        </span>
                        Home
                    </a>
                </li>
                <li class='nav-item active'>
                    <a href='/charts/newlyReleased/All' class='nav-link'
                        style='color:<?php if(Route::is('charts.index')){echo 'gold';}?>;'>
                        <span style='float: left; padding-right: 20px;'>
                            <svg class="bi bi-compass" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M8 15.016a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zm0 1a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15z" />
                                <path
                                    d="M6 1a1 1 0 0 1 1-1h2a1 1 0 0 1 0 2H7a1 1 0 0 1-1-1zm.94 6.44l4.95-2.83-2.83 4.95-4.95 2.83 2.83-4.95z" />
                            </svg>
                        </span>
                        Discover
                    </a>
                </li>
                <li class='nav-item active'>
                    <a href='/library' class='nav-link'
                        style='color:<?php if(Route::is('library.index')){echo 'gold;';}?>;'>
                        <span style='float: left; padding-right: 20px;'>
                            <svg class="bi bi-person" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M13 14s1 0 1-1-1-4-6-4-6 3-6 4 1 1 1 1h10zm-9.995-.944v-.002.002zM3.022 13h9.956a.274.274 0 0 0 .014-.002l.008-.002c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664a1.05 1.05 0 0 0 .022.004zm9.974.056v-.002.002zM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                            </svg>
                        </span>
                        Library
                    </a>
                </li>
            </ul>
        </nav>
    </div>
    <br>
    <!-- Copwrite Text -->
    <div class="copywrite-text">
        <p>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            Copyright &copy;<script>
                document.write(new Date().getFullYear());

            </script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i>
            by <a href="https://colorlib.com" target="_blank">Colorlib</a>
            <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
        </p>
    </div>
</div>
<!-- ***** Main Menu Area End ***** -->

<!-- ***** Header Area Start ***** -->
<header style="background-color: #232323;" class="header-area">
    <div class="container-fluid p-0">
        <div class="row">
            <div class="col-12" style="padding: 0;">
                <div class="menu-area d-flex justify-content-between">
                    <!-- Logo Area  -->
                    <div class="logo-area">
                        <a href="/posts">Black Music</a>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        
                        <div class="contact-form hidden">
                            <?php echo Form::open(['action' => 'SearchController@store', 'method' => 'POST']); ?>

                            <?php echo e(Form::text('search', null, ['class' => 'form-control', 'placeholder' => 'Search songs and artists', 'style' => 'text-color: white; color: white; width: 400px;'])); ?>

                            
                            <?php echo Form::close(); ?>

                        </div>
                    <?php endif; ?>

                    <div class="menu-content-area d-flex align-items-center">
                        <!-- Header Social Area -->
                        <div class="header-social-area d-flex align-items-center">

                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <a class="display-4"
                                    href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                <?php if(Route::has('register')): ?>
                                    <a class="display-4"
                                        href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                <?php endif; ?>
                            <?php else: ?>
                                
                                <?php if(auth()->user()->username
                                    == '@blackmusic'): ?>
                                    <a href="/admin">
                                        <svg class="bi bi-person" width="1em" height="1em" viewBox="0 0 16 16"
                                            fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M13 14s1 0 1-1-1-4-6-4-6 3-6 4 1 1 1 1h10zm-9.995-.944v-.002.002zM3.022 13h9.956a.274.274 0 0 0 .014-.002l.008-.002c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664a1.05 1.05 0 0 0 .022.004zm9.974.056v-.002.002zM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                        </svg>
                                    </a>
                                <?php endif; ?>
                                
                                <?php
                                    /* Get all notifications */
                                    $cartVideos = CartVideos::where('username', $user->username)->get();
                                ?>
                                <div class="dropdown">
                                    <a href="#" class='dropbtn fa fa-shopping-cart hidden' data-toggle='tooltip'
                                        data-placement='bottom' onclick="cartFunction()">
                                    </a>
                                    
                                    <span class="badge badge-danger rounded-circle hidden" style="padding: 5px 8px; position: absolute; right: -5px; top:
									-12px;"><?php if($cartVideos->count() > 0): ?><?php echo e($cartVideos->count()); ?><?php endif; ?></span>
                                    <div id="cartDropdown" class="dropdown-content dropdown-shopping">
                                        <div class='p-2 border-bottom'>
                                            <h4>Shopping Cart</h4>
                                        </div>
                                        <div style="max-height: 500px; overflow-y: scroll;">
                                            <?php if($cartVideos->count() > 0): ?>
                                                <?php $__currentLoopData = $cartVideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartVideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class='media p-2 border-bottom'>
                                                        <div class='media-left thumbnail'>
                                                            <a href='/charts/<?php echo e($cartVideo->video_id); ?>'>
                                                                <img src='/storage/<?php echo e($cartVideo->videos->video_thumbnail); ?>'
                                                                    width="160em" height="90em">
                                                            </a>
                                                        </div>
                                                        <div class='media-body ml-2'>
                                                            <h6 class="m-0"
                                                                style='width: 160px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                                                <?php echo e($cartVideo->videos->video_name); ?></h6>
                                                            <h6
                                                                style='width: 140px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                                                <small><?php echo e($cartVideo->videos->username); ?></small>
                                                            </h6>
                                                            <h6 style='color: green;'>KES 20</h6>
                                                            
                                                        </div>
                                                    </div>
                                                    </>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                            <?php if($cartVideos->count() > 0): ?>
                                                <div>
                                                    <a href="cart" class='p-3'>
                                                        <center>
                                                            <h6>Checkout</h6>
                                                        </center>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="dropdown">
                                    <?php
                                        /* Get all notifications */
                                        $notifications = Notifications::where('username',
                                        $user->username)->get();
                                        $decoNotifications = DecoNotifications::where('username',
                                        $user->username)->get();
                                        $followNotifications = FollowNotifications::where('username',
                                        $user->username)->get();
                                        $videoNotifications = VideoNotifications::where('vn_artist',
                                        $user->username)->get();
                                        $notificationBadge = $notifications->count() + $decoNotifications->count() +
                                        $followNotifications->count() + $videoNotifications->count();
                                    ?>
                                    <a href="#" class='dropbtn fa fa-bell hidden' data-toggle='tooltip'
                                        data-placement='bottom' onclick="bellFunction()">
                                    </a>
                                    <a href="#" class='dropbtn anti-hidden' data-toggle='tooltip'
                                        data-placement='bottom' onclick="bellFunction()">
                                        <svg class="bi bi-bell" width="1em" height="1em" viewBox="0 0 16 16"
                                            fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2z" />
                                            <path fill-rule="evenodd"
                                                d="M8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z" />
                                        </svg>
                                    </a>
                                    <span class="badge badge-danger rounded-circle" style="padding: 5px 8px; position: absolute; right: -5px; top:
                                        -12px;"><?php if($notificationBadge > 0): ?><?php echo e($notificationBadge); ?><?php endif; ?></span>
                                    <div id="bellDropdown" class="dropdown-content dropdown-notification">
                                        <div class='p-2 border-bottom'>
                                            <h4>Notifications</h4>
                                        </div>
                                        <div style="max-height: 500px; overflow-y: scroll;">
                                            
                                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class='border-bottom'>
                                                    <?php echo Form::open(['id' => 'notification-form', 'action' =>
                                                    ['NotificationsController@destroy', $notification->notification_id],
                                                    'method' => 'POST']); ?>

                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo Form::close(); ?>

                                                    <a href='#' class="p-2" onclick='event.preventDefault();
													 document.getElementById("notification-form").submit();'>
                                                        <h6><?php echo e($notification->message); ?></h6>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                            <?php $__currentLoopData = $decoNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $decoNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class='p-2 border-bottom'>
                                                    <a href='#'>
                                                        <p>
                                                            <small><?php echo e($decoNotification->dn_from); ?> just Decorated
                                                                you.</small>
                                                        </p>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                            <?php if($followNotifications->count() > 0): ?>
                                                <div class='p-2 border-bottom'>
                                                    <a href='#'>
                                                        <h6 style='color: purple;'>New Fans</h6>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $followNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class='p-1 border-bottom'>
                                                    <?php echo Form::open(['id' => $followNotification->follow_notification_id,
                                                    'action' =>
                                                    ['FollowNotificationsController@destroy',
                                                    $followNotification->fn_follower ], 'method' => 'POST']); ?>

                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo Form::close(); ?>

                                                    <a href='#' onclick='event.preventDefault();
													 document.getElementById("<?php echo e($followNotification->follow_notification_id); ?>").submit();'>
                                                        <p class="m-0">
                                                            <small><?php echo e($followNotification->fn_follower); ?> became a
                                                                fan.</small>
                                                        </p>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            
                                            <?php if($videoNotifications->count() > 0): ?>
                                                <div class='p-1 border-bottom'>
                                                    <a href='#'>
                                                        <h6>Songs Bought</h6>
                                                    </a>
                                                </div>
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $videoNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $videoNotification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class='p-1 border-bottom'>
                                                    <?php echo Form::open(['id' => $videoNotification->vn_id,
                                                    'action' =>
                                                    ['VideoNotificationsController@destroy',
                                                    $videoNotification->vn_id ], 'method' => 'POST']); ?>

                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo Form::close(); ?>

                                                    <a href='#' onclick='event.preventDefault();
													 document.getElementById("<?php echo e($videoNotification->vn_id); ?>").submit();'>
                                                        <p class="m-0">
                                                            <small><?php echo e($videoNotification->username); ?> just bought
                                                                <?php echo e($videoNotification->videos->video_name); ?></small>
                                                        </p>
                                                    </a>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="dropdown">
                                    <a class="dropbtn" aria-hidden="true">
                                        <img style='vertical-align: middle; width: 25px; height: 25px; border-radius: 50%;'
                                            src='/storage/<?php echo e(Auth::user()->pp); ?>' alt='Avatar' class='dropbtn'
                                            onclick='avatarFunction()'>
                                    </a>
                                    <div id="avatarDropdown" style="right: 1px;" class="dropdown-content">
                                        <div class='border-bottom'>
                                            <a href="/home/<?php echo e(Auth::user()->username); ?>" class="p-3">
                                                <h5><?php echo e(Auth::user()->name); ?></h5>
                                                <h6><?php echo e(Auth::user()->username); ?></h6>
                                            </a>
                                        </div>
                                        <div class='border-bottom'>
                                            <a href='/videos' class="p-3">
                                                <h6>Studio</h6>
                                            </a>
                                        </div>
                                        <div class='border-bottom'>
                                            <a href="/home/create" class="p-3">
                                                <h6>Settings</h6>
                                            </a>
                                        </div>
                                        <div class='border-bottom'>
                                            <a href="help.php" class="p-3">
                                                <h6>Help Centre</h6>
                                            </a>
                                        </div>
                                        <div class='border-bottom'>
                                            <a href="<?php echo e(route('logout')); ?>" class="p-3" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                <h6><?php echo e(__('Sign out')); ?></h6>
                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>"
                                                method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <!-- Menu Icon -->
                        <span class="navbar-toggler-icon hidden" id="menuIcon"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/inc/topnav.blade.php ENDPATH**/ ?>