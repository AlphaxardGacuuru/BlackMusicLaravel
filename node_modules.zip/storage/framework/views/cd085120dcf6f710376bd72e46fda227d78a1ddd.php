<!-- Preloader Start -->

<!-- Preloader End -->

<!-- Grids -->


<!-- ***** Main Menu Area Start ***** -->
<div class="mainMenu d-flex align-items-center justify-content-between">
    <!-- Close Icon -->
    <div class="closeIcon">
        <i class="ti-close" aria-hidden="true"></i>
    </div>
    <!-- Logo Area -->
    <div class="logo-area">
        <a href="/posts">Black Music</a>
    </div>
    <!-- Nav -->
    <div class="sonarNav wow fadeInUp" data-wow-delay="1s">
        <nav>
            <ul>
                <li class='nav-item active'>
                    <a href='/posts' class='nav-link'>
                        <span style='float: left; padding-right: 20px;'>
                            <svg class="bi bi-house" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M2 13.5V7h1v6.5a.5.5 0 0 0 .5.5h9a.5.5 0 0 0 .5-.5V7h1v6.5a1.5 1.5 0 0 1-1.5 1.5h-9A1.5 1.5 0 0 1 2 13.5zm11-11V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
                                <path fill-rule="evenodd"
                                    d="M7.293 1.5a1 1 0 0 1 1.414 0l6.647 6.646a.5.5 0 0 1-.708.708L8 2.207 1.354 8.854a.5.5 0 1 1-.708-.708L7.293 1.5z" />
                            </svg>
                        </span>
                        Home
                    </a>
                </li>
                <li class='nav-item active'>
                    <a href='/discover' class='nav-link'>
                        <span style='float: left; padding-right: 20px;'>
                            <svg class="bi bi-compass" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M8 15.016a6.5 6.5 0 1 0 0-13 6.5 6.5 0 0 0 0 13zm0 1a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15z" />
                                <path
                                    d="M6 1a1 1 0 0 1 1-1h2a1 1 0 0 1 0 2H7a1 1 0 0 1-1-1zm.94 6.44l4.95-2.83-2.83 4.95-4.95 2.83 2.83-4.95z" />
                            </svg>
                        </span>
                        Discover
                    </a>
                </li>
                <li class='nav-item active'>
                    <a href='/library' class='nav-link'>
                        <span style='float: left; padding-right: 20px;'>
                            <svg class="bi bi-list" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd"
                                    d="M2.5 11.5A.5.5 0 0 1 3 11h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 7h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 3h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z" />
                            </svg>
                        </span>
                        My List
                    </a>
            </ul>
        </nav>
    </div>
    <br>
</div>
<!-- ***** Main Menu Area End ***** -->

<!-- ***** Header Area Start ***** -->
<header style="background-color: #232323;" class="header-area">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12" style="padding: 0;">
                <div class="menu-area d-flex justify-content-between">
                    <!-- Logo Area  -->
                    <div class="logo-area">
                        <a href="/posts">Black Music</a>
                    </div>

                    <div class="menu-content-area d-flex align-items-center">
                        <!-- Header Social Area -->
                        <div class="header-social-area d-flex align-items-center">

                            <a href="#" onclick="carFunction()" class="hidden dropbtn">
                                <svg class="bi bi-cart3" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z" />
                                </svg>
                                <div id="cartDropdown" class="dropdown-content dropdown-shopping">
                                    <div class='myrow'>
                                        <h4>Shopping Cart</h4>
                                    </div>
                                    <div style="max-height: 500px; overflow-y: scroll;">
                                        <div class='myrow'>
                                            <div class='media'>
                                                <div class='media-left'>
                                                    <a href='play_video.php?vs_cart_song=$vs_cart_song'>
                                                        <img width='150px' height='auto' src='img/havi logos-4.png'>
                                                    </a>

                                                </div>
                                                <div class='media-body'>
                                                    $vs_cart_songname
                                                    <br>
                                                    <small>$vs_cart_songartist</small>
                                                    <br>
                                                    <br>
                                                    <a href='cart_delete.php?vs_cart_id=$vs_cart_id'
                                                        style='float: right; color: black;'><span
                                                            class='fa fa-trash'></span> <small>Delete</small></a>
                                                </div>
                                            </div>

                                        </div>
                                        <div class='myrow'>
                                            <a href='checkout.php' style='width: 0;'><button
                                                    class='mysonar-btn'>CHECKOUT</button>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </a>
                            <a onclick='bellFunction()' style='position: relative;' class='dropbtn'
                                data-toggle='tooltip' data-placement='bottom'>
                                <svg class="bi bi-bell" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 16a2 2 0 0 0 2-2H6a2 2 0 0 0 2 2z" />
                                    <path fill-rule="evenodd"
                                        d="M8 1.918l-.797.161A4.002 4.002 0 0 0 4 6c0 .628-.134 2.197-.459 3.742-.16.767-.376 1.566-.663 2.258h10.244c-.287-.692-.502-1.49-.663-2.258C12.134 8.197 12 6.628 12 6a4.002 4.002 0 0 0-3.203-3.92L8 1.917zM14.22 12c.223.447.481.801.78 1H1c.299-.199.557-.553.78-1C2.68 10.2 3 6.88 3 6c0-2.42 1.72-4.44 4.005-4.901a1 1 0 1 1 1.99 0A5.002 5.002 0 0 1 13 6c0 .88.32 4.2 1.22 6z" />
                                </svg>
                            </a>
                            <div id="bellDropdown" class="dropdown-content dropdown-notification">
                                <div class='myrow'>
                                    <h4>Notifications</h4>
                                </div>
                                <div style="max-height: 500px; overflow-y: scroll;">
                                    <div class='myrow' style='margin: 0; padding: 0;'>
                                        <a href='musicianpage.php?username=@blackmusic&bmn_id=$bmn_id'
                                            style='padding: 10px;'>
                                            <h6>$message</h6>
                                        </a>
                                    </div>

                                    <div class='myrow' style='margin: 0; padding: 0;'>
                                        <a href='musicianpage.php?dn_from=$dn_from' style='padding: 10px;'>
                                            <p>
                                                <small>$dn_from</small>
                                                <span style='color: purple;'>just Decorated </span><small>you.</small>
                                            </p>
                                        </a>
                                    </div>

                                    <div class='myrow'>
                                        <a style='color: purple;' href='#'>
                                            <h5 style='color: purple;'>New Fans</h5>
                                        </a>
                                    </div>

                                    <div class='myrow' style='margin: 0; padding: 0;'>
                                        <a href='fanpage.php?fn_follower=$fn_follower' style='padding: 10px;'>
                                            <p><small>$fn_follower</small> <span style='color: purple;'>became a
                                                    fan</span></p>
                                        </a>
                                    </div>

                                    <div class='myrow'>
                                        <a style='color: purple;' href='#'>
                                            <h5 style='color: purple;'>Songs Bought</h5>
                                        </a>
                                    </div>

                                    <div class='myrow' style='margin: 0; padding: 0;'>
                                        <a href='fanpage.php?vsn_buyer=$vsn_buyer' style='padding: 10px;'>
                                            <p><small>$vsn_buyer</small> <span style='color: purple;'>just bought
                                                </span><small>$vsn_bought_name</small></p>
                                        </a>
                                    </div>

                                </div>
                            </div>
                            </a>
                            <a href="">
                                <svg class="bi bi-person" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M13 14s1 0 1-1-1-4-6-4-6 3-6 4 1 1 1 1h10zm-9.995-.944v-.002.002zM3.022 13h9.956a.274.274 0 0 0 .014-.002l.008-.002c-.001-.246-.154-.986-.832-1.664C11.516 10.68 10.289 10 8 10c-2.29 0-3.516.68-4.168 1.332-.678.678-.83 1.418-.832 1.664a1.05 1.05 0 0 0 .022.004zm9.974.056v-.002.002zM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4zm3-2a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" />
                                </svg>
                            </a>
                            <a href="">


                                <svg class="bi bi-chat-fill" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6-.097 1.016-.417 2.13-.771 2.966-.079.186.074.394.273.362 2.256-.37 3.597-.938 4.18-1.234A9.06 9.06 0 0 0 8 15z" />
                                </svg>

                                <svg class="bi bi-check" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z" />
                                </svg>
                                <svg class="bi bi-reply" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M9.502 5.013a.144.144 0 0 0-.202.134V6.3a.5.5 0 0 1-.5.5c-.667 0-2.013.005-3.3.822-.984.624-1.99 1.76-2.595 3.876C3.925 10.515 5.09 9.982 6.11 9.7a8.741 8.741 0 0 1 1.921-.306 7.403 7.403 0 0 1 .798.008h.013l.005.001h.001L8.8 9.9l.05-.498a.5.5 0 0 1 .45.498v1.153c0 .108.11.176.202.134l3.984-2.933a.494.494 0 0 1 .042-.028.147.147 0 0 0 0-.252.494.494 0 0 1-.042-.028L9.502 5.013zM8.3 10.386a7.745 7.745 0 0 0-1.923.277c-1.326.368-2.896 1.201-3.94 3.08a.5.5 0 0 1-.933-.305c.464-3.71 1.886-5.662 3.46-6.66 1.245-.79 2.527-.942 3.336-.971v-.66a1.144 1.144 0 0 1 1.767-.96l3.994 2.94a1.147 1.147 0 0 1 0 1.946l-3.994 2.94a1.144 1.144 0 0 1-1.767-.96v-.667z" />
                                </svg>

                                <svg class="bi bi-heart-fill" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z" />
                                </svg>

                            </a>

                            <!-- Authentication Links -->
                            <?php if(auth()->guard()->guest()): ?>
                                <a class="display-4"
                                    href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                <?php if(Route::has('register')): ?>
                                    <a class="display-4"
                                        href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                <?php endif; ?>
                            <?php else: ?>

                                <!-- avatar dropdown -->
                                <div class="dropdown">
                                    <a class="dropbtn" aria-hidden="true">
                                        <img style='vertical-align: middle; width: 25px; height: 25px; border-radius: 50%;'
                                            src='img/Al.jpg' alt='Avatar' class='dropbtn' onclick='avatarFunction()'>
                                    </a>
                                    <div id="avatarDropdown" style="right: 1px;" class="dropdown-content">
                                        <div class='myrow' style="padding: 0px; margin: 0;">
                                            <a href="profile.php" style='padding: 10px;'>
                                                <h5><?php echo e(Auth::user()->name); ?></h5>
                                                <h6><?php echo e(Auth::user()->username); ?></h6>
                                            </a>
                                        </div>
                                        <div class='myrow' style='padding: 0px; margin: 0;'>
                                            <a href='studio.php' style='padding: 10px;'>
                                                <h6>Studio</h6>
                                            </a>
                                        </div>
                                        <div class='myrow' style='padding: 0px; margin: 0;'>
                                            <a href='become_musician.php' style='padding: 10px;'>
                                                <h6>Become a Musician</h6>
                                            </a>
                                        </div>
                                        <div class='myrow' style="padding: 0px; margin: 0;">
                                            <a href="settings.php" style='padding: 10px;'>
                                                <h6>Settings</h6>
                                            </a>
                                        </div>
                                        <div class='myrow' style="padding: 0px; margin: 0;">
                                            <a href="help.php" style='padding: 10px;'>
                                                <h6>Help Centre</h6>
                                            </a>
                                        </div>
                                        <div class='myrow' style="padding: 0px; margin: 0;">
                                            <a href="<?php echo e(route('logout')); ?>" style='padding: 10px;'
                                                onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                                <h6><?php echo e(__('Sign out')); ?></h6>
                                            </a>

                                            <form id="logout-form" action="<?php echo e(route('logout')); ?>"
                                                method="POST" style="display: none;">
                                                <?php echo csrf_field(); ?>
                                            </form>
                                        </div>

                                    </div>
                                </div>

                            <?php endif; ?>
                        </div>
                        <!-- Menu Icon -->
                        <span class="navbar-toggler-icon hidden" id="menuIcon"></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- ***** Header Area End ***** -->


<?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/layouts/topnav.blade.php ENDPATH**/ ?>