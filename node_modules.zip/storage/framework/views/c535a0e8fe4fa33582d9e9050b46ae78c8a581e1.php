
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php if($id == Auth::user()->username): ?>
    <?php
        $profile = Auth::user();
    ?>
<?php else: ?>
    <?php
        $profile = $users->where('username', $id)->first();
    ?>
<?php endif; ?>
<!-- Profile pic area -->
<br>
<br>
<br class="hidden">
<div class="row"
    style="background-image: url('/storage/img/headphones.jpg'); background-position: center; background-size: cover; position: relative; height: 90%;">
    <div class="col-sm-12 p-0">
        <br>
        <br class="hidden">
        <div>
            <div style="margin-top: 100px; top: 70px; left: 10px;" class="avatar-container">
                <img style="position: absolute; z-index: 99;" class="avatar hover-img"
                    src="/storage/<?php echo e($profile->pp); ?>" alt="Avatar">
            </div>
        </div>
    </div>
</div>
<!-- End of Profile pic area -->


<div class="row">
    <div class="col-sm-1"></div>
    <div class="col-sm-10">
        <br>
        <br>
        <?php if($profile->username == Auth::user()->username): ?>
            <a href="/home/<?php echo e($profile->username); ?>/edit">
                <button class="float-right mysonar-btn">edit profile</button>
            </a>
        <?php endif; ?>
        <h3><?php echo e($profile->name); ?></h3>
        <h5><?php echo e($profile->username); ?></h5>
        <h6><?php echo e($profile->bio); ?></h6>
        <div class="d-flex flex-row">
            <div class="p-2">Following
                <br>
                <?php echo e($follows->where('username', $profile->username)->count() - 2); ?>

            </div>
            <div class="p-2">Fans
                <br>
                <?php echo e($follows->where('followed', $profile->username)->count() - 1); ?>

            </div>
        </div>
    </div>
    <div class="col-sm-1"></div>
</div>

<div class="row">
    <div class="col-sm-12">
        <!-- Nav tabs -->
        <div class="card">
            <ul class="nav nav-tabs p-2" role="tablist">
                <li role="presentation" class="active p-2 mr-3">
                    <a href="#home" aria-controls="home" role="tab" data-toggle="tab">Posts</a>
                </li>
                <li role="presentation" class="p-2">
                    <a href="#profile" aria-controls="profile" role="tab" data-toggle="tab">Songs</a>
                </li>
                
            </ul>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="home">
                <?php
                    $posts = $posts->where('username', $profile->username);
                ?>
                <?php if($posts->count() > 0): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                        <?php
                            $postLikes = $post->post_likes->where('post_id', $post->post_id)->where('username',
                            $profile->username)->count();
                        ?>
                        <?php if($postLikes > 0): ?>
                            <?php
                                $heartForm = "post-like-delete-form";
                                $heart ="<span style='color: #cc3300;'>
                                    <svg class=bi bi-heart-fill width=1.2em height=1.2em viewBox=0 0 16 16
                                        fill=currentColor xmlns=http://www.w3.org/2000/svg>
                                        <path fill-rule=evenodd'
                                            d='M8 1.314C12.438-3.248 23.534 4.735 8 15-7.534 4.736 3.562-3.248 8 1.314z' />
                                    </svg>
                                </span>
                                <small>" . $post->post_likes->count() . "</small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $heartForm = "post-like-form";
                                $heart = "
                                <svg class='bi bi-heart' width='1.2em' height='1.2em' viewBox='0 0 16 16'
                                    fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                    <path fill-rule='evenodd'
                                        d='M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z' />
                                </svg>
                                <small>" . $post->post_likes->count() . "</small>";
                            ?>
                        <?php endif; ?>
                        <?php
                            $followCount = $follows->where('followed', $post->username)->where('username',
                            $profile->username)->count();
                            /* Get polls */
                            $getPolls = $polls->where('post_id', $post->post_id);
                            /* Get total polls */
                            $pollTime = (time() - strtotime($post->created_at)) / 3600;
                            if ($post->username == $profile->username || $pollTime > 24) {
                            $votes = $polls->where('post_id', $post->post_id)->count();
                            } else {
                            $votes = "ongoing...";
                            }
                            /* Check if user has voted */
                            $userPoll = $polls->where('post_id', $post->post_id)->where('username', $profile->username);
                        ?>
                        
                        
                        <?php if(!empty($post->parameter_1)): ?>
                            <?php
                                $pollCheck = $polls->where('post_id', $post->post_id)->where('parameter',
                                $post->parameter_1)->count();
                                $pollTime = (time() - strtotime($post->created_at)) / 3600;
                                if ($post->username == $profile->username || $pollTime > 24) {
                                $votesTwo = $pollCheck;
                                } else {
                                $votesTwo = "";
                                }
                                $pollParaCheck = $polls->where('post_id', $post->post_id)->where('username',
                                $profile->username)->where('parameter', $post->parameter_1)->count();
                                if ($pollCheck > 0) {
                                $percentage = round($pollCheck / $polls->where('post_id', $post->post_id)->count() *
                                100);
                                } else {
                                $percentage = 0;
                                }
                            ?>
                            
                            <?php if($pollParaCheck == 1 && $pollTime > 24): ?>
                                <?php
                                    $yourVote = "gold";
                                ?>
                            <?php else: ?>
                                <?php
                                    $yourVote = "#232323";
                                ?>
                            <?php endif; ?>
                            
                            <?php if($userPoll->count() == 0 && $pollTime < 24): ?>
                                <?php
                                    $parameter_1 = Form::button($post->parameter_1,
                                    ['type' => 'submit', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                    100%;']);
                                ?>
                            <?php else: ?>
                                
                                <?php if($pollParaCheck == 1 && $pollTime < 24): ?>
                                    <?php
                                        $parameter_1 = Form::button($post->parameter_1,
                                        ['type' => 'reset', 'class' => 'mysonar-btn mb-1 btn-2', 'style' => 'width:
                                        100%;']);
                                    ?>
                                <?php else: ?>
                                    <?php if($pollTime < 24): ?>
                                        <?php
                                            $parameter_1 = Form::button($post->parameter_1,
                                            ['type' => 'reset', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                            100%;']);
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if( $pollTime > 24 || $post->username == $profile->username) {
                                        $parameter_1 =
                                        "<div class='progress rounded-0 mb-1' style='height: 33px'>
                                            <div class='progress-bar'
                                                style='width: $percentage%; background-color: $yourVote'>
                                                $post->parameter_1 - $percentage%
                                            </div>
                                        </div>";
                                        }
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $totalVotes = "<small><i style='color: grey;'>Total votes:$votes</i></small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $parameter_1 = "";
                                $totalVotes = "";
                            ?>
                        <?php endif; ?>

                        
                        <?php if(!empty($post->parameter_2)): ?>
                            <?php
                                $pollCheck = $polls->where('post_id', $post->post_id)->where('parameter',
                                $post->parameter_2)->count();
                                $pollTime = (time() - strtotime($post->created_at)) / 3600;
                                if ($post->username == $profile->username || $pollTime > 24) {
                                $votesTwo = $pollCheck;
                                } else {
                                $votesTwo = "";
                                }
                                $pollParaCheck = $polls->where('post_id', $post->post_id)->where('username',
                                $profile->username)->where('parameter', $post->parameter_2)->count();
                                if ($pollCheck > 0) {
                                $percentage = round($pollCheck / $polls->where('post_id', $post->post_id)->count() *
                                100);
                                } else {
                                $percentage = 0;
                                }
                            ?>
                            
                            <?php if($pollParaCheck == 1 && $pollTime > 24): ?>
                                <?php
                                    $yourVote = "gold";
                                ?>
                            <?php else: ?>
                                <?php
                                    $yourVote = "#232323";
                                ?>
                            <?php endif; ?>
                            
                            <?php if($userPoll->count() == 0 && $pollTime < 24): ?>
                                <?php
                                    $parameter_2 = Form::button($post->parameter_2,
                                    ['type' => 'submit', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                    100%;']);
                                ?>
                            <?php else: ?>
                                
                                <?php if($pollParaCheck == 1 && $pollTime < 24): ?>
                                    <?php
                                        $parameter_2 = Form::button($post->parameter_2,
                                        ['type' => 'reset', 'class' => 'mysonar-btn mb-1 btn-2', 'style' => 'width:
                                        100%;']);
                                    ?>
                                <?php else: ?>
                                    <?php if($pollTime < 24): ?>
                                        <?php
                                            $parameter_2 = Form::button($post->parameter_2,
                                            ['type' => 'reset', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                            100%;']);
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if( $pollTime > 24 || $post->username == $profile->username) {
                                        $parameter_2 =
                                        "<div class='progress rounded-0 mb-1' style='height: 33px'>
                                            <div class='progress-bar'
                                                style='width: $percentage%; background-color: $yourVote'>
                                                $post->parameter_2 - $percentage%
                                            </div>
                                        </div>";
                                        }
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $totalVotes = "<small><i style='color: grey;'>Total votes:$votes</i></small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $parameter_2 = "";
                                $totalVotes = "";
                            ?>
                        <?php endif; ?>

                        
                        <?php if(!empty($post->parameter_3)): ?>
                            <?php
                                $pollCheck = $polls->where('post_id', $post->post_id)->where('parameter',
                                $post->parameter_3)->count();
                                $pollTime = (time() - strtotime($post->created_at)) / 3600;
                                if ($post->username == $profile->username || $pollTime > 24) {
                                $votesTwo = $pollCheck;
                                } else {
                                $votesTwo = "";
                                }
                                $pollParaCheck = $polls->where('post_id', $post->post_id)->where('username',
                                $profile->username)->where('parameter', $post->parameter_3)->count();
                                if ($pollCheck > 0) {
                                $percentage = round($pollCheck / $polls->where('post_id', $post->post_id)->count() *
                                100);
                                } else {
                                $percentage = 0;
                                }
                            ?>
                            
                            <?php if($pollParaCheck == 1 && $pollTime > 24): ?>
                                <?php
                                    $yourVote = "gold";
                                ?>
                            <?php else: ?>
                                <?php
                                    $yourVote = "#232323";
                                ?>
                            <?php endif; ?>
                            
                            <?php if($userPoll->count() == 0 && $pollTime < 24): ?>
                                <?php
                                    $parameter_3 = Form::button($post->parameter_3,
                                    ['type' => 'submit', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                    100%;']);
                                ?>
                            <?php else: ?>
                                
                                <?php if($pollParaCheck == 1 && $pollTime < 24): ?>
                                    <?php
                                        $parameter_3 = Form::button($post->parameter_3,
                                        ['type' => 'reset', 'class' => 'mysonar-btn mb-1 btn-2', 'style' => 'width:
                                        100%;']);
                                    ?>
                                <?php else: ?>
                                    <?php if($pollTime < 24): ?>
                                        <?php
                                            $parameter_3 = Form::button($post->parameter_3,
                                            ['type' => 'reset', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                            100%;']);
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if( $pollTime > 24 || $post->username == $profile->username) {
                                        $parameter_3 =
                                        "<div class='progress rounded-0 mb-1' style='height: 33px'>
                                            <div class='progress-bar'
                                                style='width: $percentage%; background-color: $yourVote'>
                                                $post->parameter_3 - $percentage%
                                            </div>
                                        </div>";
                                        }
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $totalVotes = "<small><i style='color: grey;'>Total votes:$votes</i></small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $parameter_3 = "";
                                $totalVotes = "";
                            ?>
                        <?php endif; ?>

                        
                        <?php if(!empty($post->parameter_4)): ?>
                            <?php
                                $pollCheck = $polls->where('post_id', $post->post_id)->where('parameter',
                                $post->parameter_4)->count();
                                $pollTime = (time() - strtotime($post->created_at)) / 3600;
                                if ($post->username == $profile->username || $pollTime > 24) {
                                $votesTwo = $pollCheck;
                                } else {
                                $votesTwo = "";
                                }
                                $pollParaCheck = $polls->where('post_id', $post->post_id)->where('username',
                                $profile->username)->where('parameter', $post->parameter_4)->count();
                                if ($pollCheck > 0) {
                                $percentage = round($pollCheck / $polls->where('post_id', $post->post_id)->count() *
                                100);
                                } else {
                                $percentage = 0;
                                }
                            ?>
                            
                            <?php if($pollParaCheck == 1 && $pollTime > 24): ?>
                                <?php
                                    $yourVote = "gold";
                                ?>
                            <?php else: ?>
                                <?php
                                    $yourVote = "#232323";
                                ?>
                            <?php endif; ?>
                            
                            <?php if($userPoll->count() == 0 && $pollTime < 24): ?>
                                <?php
                                    $parameter_4 = Form::button($post->parameter_4,
                                    ['type' => 'submit', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                    100%;']);
                                ?>
                            <?php else: ?>
                                
                                <?php if($pollParaCheck == 1 && $pollTime < 24): ?>
                                    <?php
                                        $parameter_4 = Form::button($post->parameter_4,
                                        ['type' => 'reset', 'class' => 'mysonar-btn mb-1 btn-2', 'style' => 'width:
                                        100%;']);
                                    ?>
                                <?php else: ?>
                                    <?php if($pollTime < 24): ?>
                                        <?php
                                            $parameter_4 = Form::button($post->parameter_4,
                                            ['type' => 'reset', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                            100%;']);
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if( $pollTime > 24 || $post->username == $profile->username) {
                                        $parameter_4 =
                                        "<div class='progress rounded-0 mb-1' style='height: 33px'>
                                            <div class='progress-bar'
                                                style='width: $percentage%; background-color: $yourVote'>
                                                $post->parameter_4 - $percentage%
                                            </div>
                                        </div>";
                                        }
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $totalVotes = "<small><i style='color: grey;'>Total votes:$votes</i></small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $parameter_4 = "";
                                $totalVotes = "";
                            ?>
                        <?php endif; ?>

                        
                        <?php if(!empty($post->parameter_5)): ?>
                            <?php
                                $pollCheck = $polls->where('post_id', $post->post_id)->where('parameter',
                                $post->parameter_5)->count();
                                $pollTime = (time() - strtotime($post->created_at)) / 3600;
                                if ($post->username == $profile->username || $pollTime > 24) {
                                $votesTwo = $pollCheck;
                                } else {
                                $votesTwo = "";
                                }
                                $pollParaCheck = $polls->where('post_id', $post->post_id)->where('username',
                                $profile->username)->where('parameter', $post->parameter_5)->count();
                                if ($pollCheck > 0) {
                                $percentage = round($pollCheck / $polls->where('post_id', $post->post_id)->count() *
                                100);
                                } else {
                                $percentage = 0;
                                }
                            ?>
                            
                            <?php if($pollParaCheck == 1 && $pollTime > 24): ?>
                                <?php
                                    $yourVote = "gold";
                                ?>
                            <?php else: ?>
                                <?php
                                    $yourVote = "#232323";
                                ?>
                            <?php endif; ?>
                            
                            <?php if($userPoll->count() == 0 && $pollTime < 24): ?>
                                <?php
                                    $parameter_5 = Form::button($post->parameter_5,
                                    ['type' => 'submit', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                    100%;']);
                                ?>
                            <?php else: ?>
                                
                                <?php if($pollParaCheck == 1 && $pollTime < 24): ?>
                                    <?php
                                        $parameter_5 = Form::button($post->parameter_5,
                                        ['type' => 'reset', 'class' => 'mysonar-btn mb-1 btn-2', 'style' => 'width:
                                        100%;']);
                                    ?>
                                <?php else: ?>
                                    <?php if($pollTime < 24): ?>
                                        <?php
                                            $parameter_5 = Form::button($post->parameter_5,
                                            ['type' => 'reset', 'class' => 'mysonar-btn mb-1', 'style' => 'width:
                                            100%;']);
                                        ?>
                                    <?php endif; ?>
                                    <?php
                                        if( $pollTime > 24 || $post->username == $profile->username) {
                                        $parameter_5 =
                                        "<div class='progress rounded-0 mb-1' style='height: 33px'>
                                            <div class='progress-bar'
                                                style='width: $percentage%; background-color: $yourVote'>
                                                $post->parameter_5 - $percentage%
                                            </div>
                                        </div>";
                                        }
                                    ?>
                                <?php endif; ?>
                            <?php endif; ?>
                            <?php
                                $totalVotes = "<small><i style='color: grey;'>Total votes:$votes</i></small>";
                            ?>
                        <?php else: ?>
                            <?php
                                $parameter_5 = "";
                                $totalVotes = "";
                            ?>
                        <?php endif; ?>

                        
                        <?php if($followCount == 1): ?>
                            <div class='media p-2 border-bottom'>
                                <div class='media-left'>
                                    <a href='/home/<?php echo e($post->username); ?>'>
                                        <img src='/storage/<?php echo e($post->user->pp); ?>'
                                            style='float: right; vertical-align: top; width: 40px; height: 40px; border-radius: 50%;'
                                            alt='avatar'>
                                    </a>
                                </div>
                                <div class='media-body'>
                                    <h6 class="media-heading m-0"
                                        style='width: 100%; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                        <b><?php echo e($post->user->name); ?></b><small><?php echo e($post->username); ?></small>
                                        <span style='color: gold;'>
                                            <svg class="bi bi-circle" width="1em" height="1em" viewBox="0 0 16 16"
                                                fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd"
                                                    d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                            </svg>
                                        </span>
                                        <span style='font-size: 10px;'><?php echo e($post->user->deco); ?></span>
                                        <small>
                                            <i
                                                class="float-right mr-1"><?php echo e($post->created_at->format('j-M-Y')); ?></i>
                                        </small>
                                    </h6>
                                    <p class="mb-0">
                                        <?php echo e($post->text); ?>

                                    </p>
                                    
                                    <?php if(!empty($post->media)): ?>
                                        <div class="mb-1" style="border-top-left-radius: 10px; border-top-right-radius: 10px;
                                    border-bottom-right-radius: 10px; border-bottom-left-radius: 10px; overflow:
                                    hidden; width: 100%; height: auto;">
                                            <img src="/storage/<?php echo e($post->media); ?>" alt="" width="auto" height="auto">
                                        </div>
                                    <?php elseif(!empty($post->parameter_1)): ?>
                                        
                                        
                                        <?php echo Form::open(['action' => 'PollsController@store', 'method' => 'POST']); ?>

                                        <?php echo $parameter_1; ?>

                                        <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                        <?php echo e(Form::hidden('parameter', $post->parameter_1)); ?>

                                        <?php echo Form::close(); ?>

                                        
                                        <?php echo Form::open(['action' => 'PollsController@store', 'method' => 'POST']); ?>

                                        <?php echo $parameter_2; ?>

                                        <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                        <?php echo e(Form::hidden('parameter', $post->parameter_2)); ?>

                                        <?php echo Form::close(); ?>

                                        
                                        <?php echo Form::open(['action' => 'PollsController@store', 'method' => 'POST']); ?>

                                        <?php echo $parameter_3; ?>

                                        <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                        <?php echo e(Form::hidden('parameter', $post->parameter_3)); ?>

                                        <?php echo Form::close(); ?>

                                        
                                        <?php echo Form::open(['action' => 'PollsController@store', 'method' => 'POST']); ?>

                                        <?php echo $parameter_4; ?>

                                        <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                        <?php echo e(Form::hidden('parameter', $post->parameter_4)); ?>

                                        <?php echo Form::close(); ?>

                                        
                                        <?php echo Form::open(['action' => 'PollsController@store', 'method' => 'POST']); ?>

                                        <?php echo $parameter_5; ?>

                                        <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                        <?php echo e(Form::hidden('parameter', $post->parameter_5)); ?>

                                        <?php echo $totalVotes; ?>

                                        <?php echo Form::close(); ?>

                                    <?php endif; ?>

                                    
                                    <?php echo Form::open(['id' => $post->post_id, 'action' => 'PostLikesController@store',
                                    'method' => 'POST']); ?>

                                    <?php echo e(Form::hidden('post-id', $post->post_id)); ?>

                                    <?php echo e(Form::hidden('to', '/home/' . $profile->username)); ?>

                                    <?php echo Form::close(); ?>

                                    <a href='#' onclick='event.preventDefault();
													 document.getElementById("<?php echo e($post->post_id); ?>").submit();'>
                                        <?php echo $heart; ?>

                                    </a>
                                    
                                    <a href="posts/<?php echo e($post->post_id); ?>">
                                        <svg class="bi bi-chat ml-5" width="1.2em" height="1.2em" viewBox="0 0 16 16"
                                            fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z" />
                                        </svg>
                                        <small><?php echo e($post->post_comments->count()); ?></small>
                                    </a>
                                    <span style='cursor: pointer;' class='w3dropup float-right'>
                                        <span>
                                            <svg class="bi bi-three-dots-vertical" width="1em" height="1em"
                                                viewBox="0 0 16 16" fill="currentColor"
                                                xmlns="http://www.w3.org/2000/svg">
                                                <path fill-rule="evenodd"
                                                    d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                            </svg>
                                        </span>
                                        <span class='w3dropup-content'>
                                            <?php
                                                $postD = 'post-delete-form' . $post->post_id;
                                            ?>
                                            <?php if($profile->username
                                                == Auth::user()->username): ?>
                                                <?php if($post->username != $profile->username): ?>
                                                    <?php if($post->username
                                                        != '@blackmusic'): ?>
                                                        <a href='#'>
                                                            <h6>Mute</h6>
                                                        </a>
                                                        <a href='#'>
                                                            <h6>Unfollow <?php echo e($post->poster_id); ?></h6>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo Form::open(['id' => $postD, 'action' =>
                                                    ['PostsController@destroy',
                                                    $post->post_id], 'method' => 'POST']); ?>

                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo Form::close(); ?>

                                                    <a href='#' onclick='event.preventDefault();
													 document.getElementById("<?php echo e($postD); ?>").submit();'>
                                                        <h6>Delete post</h6>
                                                    </a>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php if($post->username == $profile->username): ?>
                                                    <?php if($post->username
                                                        != '@blackmusic'): ?>
                                                        <a href='#'>
                                                            <h6>Mute</h6>
                                                        </a>
                                                        <a href='#'>
                                                            <h6>Unfollow <?php echo e($post->poster_id); ?></h6>
                                                        </a>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <?php echo Form::open(['id' => $postD, 'action' =>
                                                    ['PostsController@destroy',
                                                    $post->post_id], 'method' => 'POST']); ?>

                                                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                    <?php echo Form::close(); ?>

                                                    <a href='#' onclick='event.preventDefault();
													 document.getElementById("<?php echo e($postD); ?>").submit();'>
                                                        <h6>Delete post</h6>
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </span>
                                    </span>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="profile">
                <h5>
                    <center><span style="border-bottom: solid 2px black;">Songs</span></center>
                </h5>
                <br>
                <?php
                    $videos = $videos->where('username', $profile->username);
                ?>
                <?php if(count($videos) > 0): ?>
                    <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            /* Check if song is in cart */
                            $cartVideoQuery = $cartVideos->where('video_id', $video->video_id)->where('username',
                            $profile->username)->count();
                            /* Check if song is bought */
                            $boughtVideoQuery = $boughtVideos->where('username',
                            $profile->username)->where('video_id', $video->video_id)->count();
                            if ($cartVideoQuery > 0) {
                            $cart = "<button class='btn btn-light mb-1' style='min-width: 40px; height: 33px;'>
                                <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16'
                                    fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                    <path fill-rule='evenodd'
                                        d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                                </svg>";
                                $bbtn = "<button class='btn mysonar-btn green-btn float-right'>buy</button>";
                                } else {
                                if ($boughtVideoQuery > 0) {
                                $cart = "";
                                $bbtn = "<button class='btn btn-sm btn-light float-right'>Owned
                                    <svg class='bi bi-check' width='1em' height='1em' viewBox='0 0 16 16'
                                        fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                        <path fill-rule='evenodd'
                                            d='M10.97 4.97a.75.75 0 0 1 1.071 1.05l-3.992 4.99a.75.75 0 0 1-1.08.02L4.324 8.384a.75.75 0 1 1 1.06-1.06l2.094 2.093 3.473-4.425a.236.236 0 0 1 .02-.022z' />
                                    </svg>";
                                    } else {
                                    $cart = "<button class='mysonar-btn mb-1' style='min-width: 40px;'>
                                        <svg class='bi bi-cart3' width='1em' height='1em' viewBox='0 0 16 16'
                                            fill='currentColor' xmlns='http://www.w3.org/2000/svg'>
                                            <path fill-rule='evenodd'
                                                d='M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 0 0 2 1 1 0 0 0 0-2zm7 0a1 1 0 1 0 0 2 1 1 0 0 0 0-2z' />
                                        </svg>";
                                        $cForm = "";
                                        $bbtn = "<button class='btn mysonar-btn green-btn float-right'>buy</button>";
                                        $dForm = "";
                                        }
                                        }
                        ?>
                        <?php if($boughtVideoQuery == 0): ?>
                            <div class="media p-2 border-bottom">
                                <div class="media-left thumbnail">
                                    <a href='/charts/<?php echo e($video->video_id); ?>'>
                                        <img src='/storage/<?php echo e($video->video_thumbnail); ?>' width="160em" height="90em">
                                    </a>
                                </div>
                                <div class="media-body ml-2">
                                    <h6 class="m-0"
                                        style='width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                        <?php echo e($video->video_name); ?></h6>
                                    <h6 class="m-0">
                                        <small><?php echo e($video->username); ?> <?php echo e($video->ft); ?></small>
                                    </h6>
                                    <h6>
                                        <small class="m-0">
                                            <?php echo e($video->bought_videos->count()); ?> Downloads
                                        </small>
                                    </h6>
                                    
                                    <?php echo Form::open(['id' => 'video-cart-form' . $video->video_id, 'action' =>
                                    'CartVideosController@store',
                                    'method' => 'POST']); ?>

                                    <?php echo e(Form::hidden('cart-video-song', $video->video_id)); ?>

                                    <?php echo e(Form::hidden('to', 'posts')); ?>

                                    <?php echo Form::close(); ?>

                                    
                                    <?php echo Form::open(['id' => 'video-buy-form' . $video->video_id, 'action' =>
                                    'CartVideosController@store',
                                    'method' => 'POST']); ?>

                                    <?php echo e(Form::hidden('cart-video-song', $video->video_id)); ?>

                                    <?php echo e(Form::hidden('to', 'cart')); ?>

                                    <?php echo Form::close(); ?>

                                    <a href='#' style="color: #000;"
                                        onclick='event.preventDefault();
													 document.getElementById("<?php echo e('video-cart-form' . $video->video_id); ?>").submit();'>
                                        <?php echo $cart; ?>

                                    </a>
                                    <a href='#' style="color: #000;"
                                        onclick='event.preventDefault();
													 document.getElementById("<?php echo e('video-buy-form' . $video->video_id); ?>").submit();'>
                                        <?php echo $bbtn; ?>

                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
            <div role="tabpanel" class="tab-pane" id="messages">Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the
                1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
                book.
                It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                sheets containing Lorem Ipsum passages, and more recently
                with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</div>
            <div role="tabpanel" class="tab-pane" id="settings">Lorem Ipsum is simply dummy text of the printing
                and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the
                1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen
                book.
                It has survived not only five centuries, but also the leap into electronic typesetting,
                remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset
                sheets containing Lorem Ipsum passage..</div>
        </div>
    </div>
    <div class="col-sm-4"></div>
</div>
</div>
</div>
<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/profile.blade.php ENDPATH**/ ?>