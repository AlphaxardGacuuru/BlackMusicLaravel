

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('inc/topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if(auth()->guard()->guest()): ?>
    <?php
        class Fruit {
        /* Properties */
        public $name = 'Guest';
        public $username = '@guest';
        public $deco = '0';
        }

        $user = new Fruit();
    ?>
<?php else: ?>
    <?php
        $user = Auth::user();
    ?>
<?php endif; ?>

<a href="/posts/create" id="floatBtn">
    <span style='font-size: 30px;' class='fa fa-pencil'></span>
</a>

<br>
<br>
<br class="hidden">

<!-- Profile info area -->
<div class="row">
    <div class="col-sm-1 hidden"></div>
    <div class="col-sm-3 hidden">
        <div class="card">
            <table class="table table-hover">
                <tr>
                    <td style="border: none;">
                        <a href='profile.php'>
                            <img src='img/Al.jpg'
                                style='vertical-align: top; width: 100px; height: 100px; border-radius: 50%;'
                                alt='avatar'>
                        </a>
                    <td style="border: none;">

                        <span>
                            <h5
                                style='padding: 0px 0px 0 0; margin: 0 0; width: 160px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                <?php echo e($user->name); ?>

                            </h5>
                            <h6
                                style='padding: 0px 0px 0px 0px; margin: 0 0; width: 140px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                                <small><?php echo e($user->username); ?></small>
                            </h6>
                            <span style='color: gold;'>
                                <svg class="bi bi-circle" width="1em" height="1em" viewBox="0 0 16 16"
                                    fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                    <path fill-rule="evenodd"
                                        d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                </svg>
                            </span>
                            <span style='font-size: 10px;'> <?php echo e($user->deco); ?></span>
                    </td>
                </tr>
                <tr>
                    <td>
                        <h6>Posts</h6>
                        <br>

                    </td>
                    <td style='color: purple;'>
                        <a href='fans.php'>
                            <h6>Fans</h6>
                            <br>
                        </a>
                    </td>
                </tr>
            </table>
        </div>
        <!-- Profile info area End -->
        <br>
        <!-- Musician suggestions area -->
        <div class="card">
            <table class="table table-hover">
                <tr>
                    <th style="border: none;">
                        <h2>Musicians to follow</h2>
                    </th>
                </tr>
                <tr>
                    <td>

                        <div class='media'>
                            <div class='media-left'>
                                <a href='musicianpage.php?username=username'><img src='img/Al.jpg'
                                        style='float: right; vertical-align: top; width: 30px; height: 30px; border-radius: 50%;'
                                        alt='avatar'></a>
                            </div>
                            <div class='media-body'>
                                <b>name</b>
                                <small><i>username</i></small>
                                <a href='follows.php?username=$username&from=home'><button type='submit'
                                        style='float: right;' class='mysonar-btn'>follow</button></a>

                                <br>
                                <small style='color: grey;'><i>promoted</i></small>
                            </div>
                        </div>

                    </td>
                </tr>

                <!-- The actual snackbar for following message -->
                <div id='checker'>You must have bought atleast 1 song by that Musician</div>

            </table>
        </div>
    </div>
    <!-- Musician suggestion area end -->

    <div class="col-sm-4">
        <div class="card">
            <!-- ****** Songs Area ****** -->
            <div class="p-2 border-bottom">
                <h5>Songs for you</h5>
                <div class="hidden-scroll">
                    <span class="card"
                        style='border: 0px solid lightgrey; padding: 0rem 0rem 10px 0rem; border-radius: 10px;'>
                        <div class="thumbnail" style="border-top-left-radius: 10px; border-top-right-radius: 10px;">
                            <a href='play_video.php?vsong_id=vsong_id'>
                                <img src='img/Al.jpg' width="160em" height="90em">
                            </a>
                        </div>
                        <h6
                            style='padding: 10px 5px 0 5px; margin: 0px; width: 150px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            vsong_name</h6>
                        <h6 style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>
                            <small>vsong_artist ft</small>
                        </h6>
                        <h6>
                            <small style='margin: 0px 5px 0px 5px; padding: 0px 5px 0px 5px;'>vsong_downloads
                                Do</small>
                        </h6>

                        <a href='vs_cart.php?vsong_id=$vsong_id&from=home' style='min-width: 90px;'
                            class='btn mysonar-btn'>
                            <span class='fa fa-shopping-cart'></span>
                        </a>
                        <br>
                        <a href='vs_cart.php?vsong_id=$vsong_id&from=checkout' class='btn mysonar-btn green-btn'
                            style='margin: 5px 0 0 0;'>buy</a>
                    </span>
                </div>
                <button id="myCheckOne" class="left mysonar-btn myScrollBtn hidden" style="float: left; left: -1rem;">
                    < </button> <button id="myCheckTwo" class="right mysonar-btn myScrollBtn hidden"
                            style="float: right; right: -1rem;">></button>
            </div>
            <!-- ****** Songs Area End ****** -->

            <!-- Posts area -->
            <?php if(count($posts) > 0): ?>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class='p-2 border-bottom'>
                        <div class='media'>
                            <div class='media-left'>
                                <a href='/pages/<?php echo e($post->poster_id); ?>'>
                                    <img src='img/Al.jpg'
                                        style='float: right; vertical-align: top; width: 40px; height: 40px; border-radius: 50%;'
                                        alt='avatar'>
                                </a>
                            </div>

                            <div style='padding-left: 1%;' class='media-body'>
                                <b class='media-heading'>name</b>
                                <span style='color: gold; padding-top: 10px;'>
                                    <svg class="bi bi-circle" width="1em" height="1em" viewBox="0 0 16 16"
                                        fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd"
                                            d="M8 15A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z" />
                                    </svg>
                                </span>
                                <span style='font-size: 10px;'>deco</span>

                                <small>
                                    <i
                                        style='float: right; padding-right: 2px;'><?php echo e($post->created_at->format('j-M-Y')); ?></i>
                                    <br>

                                    <i><?php echo e($post->poster_id); ?></i>
                                </small>

                                <p class="mb-0"><?php echo e($post->post_text); ?></p>

                                <div class="mb-1" style="border-top-left-radius: 10px; border-top-right-radius: 10px;
                                    border-bottom-right-radius: 10px; border-bottom-left-radius: 10px; overflow:
                                    hidden; width: 100%; height: auto;">
                                    <img src="/storage<?php echo e($post->post_media); ?>" alt="" width="auto" height="auto">
                                </div>
                                <a href='post_loves.php?post_id=$post_id'>
                                    <svg class="bi bi-heart" width="1em" height="1em" viewBox="0 0 16 16"
                                        fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd"
                                            d="M8 2.748l-.717-.737C5.6.281 2.514.878 1.4 3.053c-.523 1.023-.641 2.5.314 4.385.92 1.815 2.834 3.989 6.286 6.357 3.452-2.368 5.365-4.542 6.286-6.357.955-1.886.838-3.362.314-4.385C13.486.878 10.4.28 8.717 2.01L8 2.748zM8 15C-7.333 4.868 3.279-3.04 7.824 1.143c.06.055.119.112.176.171a3.12 3.12 0 0 1 .176-.17C12.72-3.042 23.333 4.867 8 15z" />
                                    </svg>
                                </a>

                                <small><?php echo e($post->post_num_loves); ?></small>

                                <a style='padding-left: 20%;' href='commenting.php?post_id=post_id'>
                                    <svg class="bi bi-chat" width="1em" height="1em" viewBox="0 0 16 16"
                                        fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                        <path fill-rule="evenodd"
                                            d="M2.678 11.894a1 1 0 0 1 .287.801 10.97 10.97 0 0 1-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 0 1 .71-.074A8.06 8.06 0 0 0 8 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 0 1-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 0 0 .244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 0 1-2.347-.306c-.52.263-1.639.742-3.468 1.105z" />
                                    </svg>
                                </a>

                                <small><?php echo e($post->post_num_comments); ?></small>

                                <?php echo e($post->parameter_1); ?> . <small style='color: orange;'>votes_2</small> <a
                                    href='polls.php?post_id=$post_id&parameter_5=$parameter_5'
                                    style='float: right;'>vote_button</a><br>
                                <?php echo e($post->parameter_2); ?> . <small style='color: orange;'>votes_2</small> <a
                                    href='polls.php?post_id=$post_id&parameter_5=$parameter_5'
                                    style='float: right;'>vote_button</a><br>
                                <?php echo e($post->parameter_3); ?> . <small style='color: orange;'>votes_2</small> <a
                                    href='polls.php?post_id=$post_id&parameter_5=$parameter_5'
                                    style='float: right;'>vote_button</a><br>
                                <?php echo e($post->parameter_4); ?> . <small style='color: orange;'>votes_2</small> <a
                                    href='polls.php?post_id=$post_id&parameter_5=$parameter_5'
                                    style='float: right;'>vote_button</a><br>
                                <?php echo e($post->parameter_5); ?> . <small style='color: orange;'>votes_2</small> <a
                                    href='polls.php?post_id=$post_id&parameter_5=$parameter_5'
                                    style='float: right;'>vote_button</a><br>


                                <span style='cursor: pointer; float: right; padding: 3%;' class='w3dropup'>
                                    <span>
                                        <svg class="bi bi-three-dots-vertical" width="1em" height="1em"
                                            viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                                            <path fill-rule="evenodd"
                                                d="M9.5 13a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm0-5a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
                                        </svg>
                                    </span>
                                    <span class='w3dropup-content'>
                                        <a href='mute.php?username=$username'>
                                            <h6>Mute</h6>
                                        </a>
                                        <a href='follows.php?username=$username'>
                                            <h6>Unfollow <?php echo e($post->poster_id); ?></h6>
                                        </a>
                                        <a href="/posts/<?php echo e($post->post_id); ?>/destroy" onclick="event.preventDefault();
                                                     document.getElementById('postdelete-form').submit();">
                                            <h6>Delete post</h6>
                                        </a>
                                        <?php echo Form::open(['id' => 'postdelete-form', 'action' =>
                                        ['PostsController@destroy',
                                        $post->post_id], 'method'
                                        => 'POST']); ?>

                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                        <?php echo Form::close(); ?>

                                    </span>
                                </span>

                            </div>

                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
    <!-- Posts area end -->

    <!-- Song suggestion area -->
    <div class="col-sm-3 hidden">
        <div class="card">
            <div class="p-2 border-bottom">
                <h5>Songs to watch</h5>
            </div>
            <div class='p-2 border-b0ttom'>
                <div class='media'>
                    <div class='media-left thumbnail' style='padding: 0rem 0.5rem 0rem 0rem;'>
                        <a href='play_video.php?vsong_id=vsong_id'>
                            <img src='img/Al.jpg' width="160em" height="90em">
                        </a>
                    </div>

                    <div class='media-body'>
                        <h6
                            style='padding: 0px 0px 0 0; margin: 0 0; width: 140px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            vsong_name
                        </h6>
                        <h6
                            style='padding: 0px 0px 0px 0px; margin: 0 0; width: 140px; white-space: nowrap; overflow: hidden; text-overflow: clip;'>
                            <small>vsong_artist ft</small></h6>
                        <h6><small>vsong_downloads Downloads</small></h6>

                        <a style='color: grey; min-width: 50px;' class='btn btn-sm btn-default'>
                            <span class='fa fa-shopping-cart'></span></a>
                        <a href='vs_cart.php?vsong_id=$vsong_id&from=checkout' class='btn mysonar-btn green-btn'
                            style='float: right;'>buy</a>

                    </div>
                </div>

            </div>
        </div>
        <!-- End of Song Suggestion Area -->

    </div>
    <div class="col-sm-1"></div>
</div>

<?php echo $__env->make('inc/bottomnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/pages/index.blade.php ENDPATH**/ ?>