
<h1>footer</h1>

<!-- ***** Footer Area Start ***** -->
<footer class="footer-area">
    <!-- back end content -->
    <div class="backEnd-content">
        <img class="dots" src="img/core-img/dots.png" alt="">
    </div>
</footer>
<!-- ***** Footer Area End ***** -->

<!-- jQuery (Necessary for All JavaScript Plugins) -->
<script src="<?php echo e(asset('js/jquery/jquery-2.2.4.min.js')); ?>"></script>
<!-- Popper js -->
<!-- <script src="js/popper.min.js"></script> -->
<!-- Bootstrap js -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<!-- Plugins js -->
<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
<!-- Active js -->
<script src="<?php echo e(asset('js/active.j')); ?>s"></script>

<!-- Black Music JS -->
<script src="<?php echo e(asset('black_music.js')); ?>"></script>
</body>
</html><?php /**PATH C:\xampp\htdocs\Black-Music-v2\resources\views/layouts/footer.blade.php ENDPATH**/ ?>