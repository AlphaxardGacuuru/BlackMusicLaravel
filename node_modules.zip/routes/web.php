<?php
// use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
 */
Route::redirect('/', 'posts');
Auth::routes();
Route::resources([
    '/home' => 'HomeController',
    'posts' => 'PostsController',
    'videos' => 'VideosController',
    'video-notifications' => 'VideoNotificationsController',
    'library' => 'BoughtVideosController',
    'follows' => 'FollowsController',
    'follow-notifications' => 'FollowNotificationsController',
    'cart' => 'CartVideosController',
    'post-likes' => 'PostLikesController',
    'post-comments' => 'PostCommentsController',
    'post-comments-likes' => 'PostCommentLikesController',
    'polls' => 'PollsController',
    'video-likes' => 'VideoLikesController',
    'video-comments' => 'VideoCommentsController',
    'video-comment-likes' => 'VideoCommentLikesController',
    'referrals' => 'ReferralsController',
    'search' => 'SearchController',
    'admin' => 'PayoutsController',
    'notifications' => 'NotificationsController',
    'kopokopo' => 'KopokopoController',
    'user' => 'UserController',
]);
Route::get('/charts/{chart}/{vGenre}', [
    'as' => 'charts.index',
    'uses' => 'ChartsController@index',
]);
Route::resource('charts', 'ChartsController', ['except' => 'index']);
Route::view('social', '/auth/social');
// Route::get('email', function () {

//     Mail::to('alphaxardgacuuru47@gmail.com')->send(new WelcomeMail());

//     return new WelcomeMail();
// });

Route::get('login/{website}', 'Auth\LoginController@redirectToProvider');
Route::get('login/{website}/callback', 'Auth\LoginController@handleProviderCallback');
